"""
regards.py

Backend FastAPI para Voicebot (OpenAI Realtime VAD).

- Control de turnos: el backend nunca reenvía audio mientras el asistente habla.
- Reconexión automática si OpenAI cierra el WebSocket (cód. 1000 OK).
- Verificación de variables de entorno (API_KEY, WS_URL) dentro de open_openai_ws().
"""

import asyncio
import json
import logging
import os
import ssl
from typing import Dict, List

import websockets
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from websockets.exceptions import ConnectionClosedOK


# * Configuración: Loggers, env vars, system message y voz, listado de clientes y router


logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

API_KEY = os.getenv("API_KEY")
OPENAI_WS_URL = os.getenv("WS_URL")

SYSTEM_MESSAGE = "Responde siempre en español, breve y claro."
VOICE = "ash"

CONNECTED_CLIENTS: List[WebSocket] = []
CCARouter = APIRouter()


# * Helper functions


async def forward_to_clients(raw: str):
    """
    Envía un mensaje JSON recibido de OpenAI a todos los navegadores conectados.
    Ignora silenciosamente los clientes que ya cerraron.
    """

    for client in list(CONNECTED_CLIENTS):
        try:
            await client.send_text(raw)
        except Exception:
            pass


async def send_session_config(ws):
    """
    Envía al WebSocket de OpenAI el mensaje `session.update` con:
    - instrucciones de sistema
    - parámetros de VAD basados en server_vad
    - configuración de voz y formatos de audio
    """

    await ws.send(
        json.dumps(
            {
                "type": "session.update",
                "session": {
                    "instructions": SYSTEM_MESSAGE,
                    "turn_detection": {
                        "type": "server_vad",
                        "threshold": 0.5,
                        "prefix_padding_ms": 300,
                        "silence_duration_ms": 500,
                    },
                    "voice": VOICE,
                    "input_audio_format": "pcm16",
                    "output_audio_format": "pcm16",
                    "modalities": ["text", "audio"],
                },
            }
        )
    )

    logger.info("→ session.update enviada")


async def receive_from_openai(ws, state: Dict):
    """
    Bucle asíncrono que recibe todos los eventos de OpenAI.

    - Cuando detecta el inicio de respuesta, marca `awaiting_response` y envía
      `input_audio_buffer.stop` para cortar posibles restos en cola.
    - Al final (`response.audio.end` / `response.done`) libera el flag y
      reenvía cualquier audio del usuario almacenado en `state["buffer"]`.
    - Reenvía todos los mensajes al/los cliente/s vía forward_to_clients().
    """

    try:
        async for raw in ws:
            msg = json.loads(raw)
            t = msg.get("type", "")

            # Inicio del turno del bot
            if t in ("response.start", "response.audio.start"):
                state["awaiting_response"] = True
                await ws.send(json.dumps({"type": "input_audio_buffer.stop"}))

            # Fin de turno del bot
            if t in ("response.audio.end", "response.done"):
                state["awaiting_response"] = False

                # Reenvía audio del usuario que se almacenó mientras el bot hablaba
                while state["buffer"]:
                    chunk = state["buffer"].pop(0)
                    await ws.send(
                        json.dumps(
                            {"type": "input_audio_buffer.append", "audio": chunk}
                        )
                    )

            await forward_to_clients(raw)

    # Cierre “normal” → marcamos para reconexión
    except ConnectionClosedOK:
        state["closed"] = True
        logger.info("OpenAI cerró la sesión (1000 OK)")

    # Cierre por errores
    except Exception as e:
        state["closed"] = True
        logger.error(f"receive_from_openai: {e}")


async def open_openai_ws(state: Dict):
    """
    Abre (o reabre) un WebSocket con la API Realtime.

    Comprueba aquí las variables de entorno para permitir
    importación del módulo sin romper el servidor si faltan.
    """

    # Comprueba que existan las env vars
    if not API_KEY or not OPENAI_WS_URL:
        raise RuntimeError("Faltan variables de entorno API_KEY o WS_URL")

    # TODO: SSL sin certificado, en producción no puede estar
    ssl_ctx = ssl.create_default_context()
    ssl_ctx.check_hostname = False
    ssl_ctx.verify_mode = ssl.CERT_NONE

    # Headers de conexión
    headers = {"Authorization": f"Bearer {API_KEY}", "OpenAI-Beta": "realtime=v1"}

    # Conexión por websocket a OpenAI
    ws = await websockets.connect(
        OPENAI_WS_URL,
        extra_headers=headers,
        ssl=ssl_ctx,
        ping_interval=20,
        ping_timeout=20,
        max_size=None,
    )

    # Envía config inicial y lanza task de recepción
    await send_session_config(ws)

    state.update({"awaiting_response": False, "closed": False})
    asyncio.create_task(receive_from_openai(ws, state))

    # Imprime mensaje de conexión y devuelve la conexión por ws
    logger.info("✅ WebSocket OpenAI conectado")
    return ws


# * Endpoints


@CCARouter.websocket("/web-client")
async def websocket_endpoint(websocket: WebSocket):
    """
    - Acepta conexiones WebSocket del navegador
    - Conecta (o reconecta) con OpenAI mediante websocket
    - Puentea audio y eventos, respetando el control de turno
    """

    # Acepta la conexión recibida y la añade a la lista
    await websocket.accept()
    CONNECTED_CLIENTS.append(websocket)

    logger.info(f"Cliente conectado ({len(CONNECTED_CLIENTS)})")

    # Crea un state de la sesión para la conexión con openai por ws
    state = {
        "awaiting_response": False,  # Turno del bot
        "buffer": [],  # audio del usuario almacenado
        "closed": False,  # WS con OpenAI está cerrado
    }

    # Realiza la conexión por ws con openai pasando el state creado
    openai_ws = await open_openai_ws(state)

    try:
        while True:
            # Se recoge el mensaje del cliente
            data = await websocket.receive_text()
            msg = json.loads(data)

            # Reconecta si OpenAI se había cerrado
            if state["closed"]:
                try:
                    openai_ws = await open_openai_ws(state)
                except Exception as e:
                    logger.error(f"Reconexión fallida: {e}")
                    continue

            # Si el mensaje es de tipo audio
            # Si el bot está hablando, lo almacena; si no, lo envía directo
            if msg.get("type") == "audio_data":
                if state["awaiting_response"]:
                    state["buffer"].append(msg["audio"])
                else:
                    try:
                        await openai_ws.send(
                            json.dumps(
                                {
                                    "type": "input_audio_buffer.append",
                                    "audio": msg["audio"],
                                }
                            )
                        )
                    except ConnectionClosedOK:
                        state["closed"] = True
            elif msg.get("type") == "input_audio_buffer.stop":
                try:
                    await openai_ws.send(
                        json.dumps({"type": "input_audio_buffer.stop"})
                    )
                except ConnectionClosedOK:
                    state["closed"] = True

    # Controla el cierre de websocket por parte del cliente
    except WebSocketDisconnect:
        logger.info("Cliente navegador desconectado")

    # Cierra la conexión por websocket y la conexión por ws con openai
    finally:
        CONNECTED_CLIENTS.remove(websocket)

        try:
            await openai_ws.close()
        except Exception:
            pass
