"""
main.py

Punto de entrada de la aplicación FastAPI.
Carga las variables de entorno desde .env y arranca el servidor.
"""

from dotenv import load_dotenv

# Carga las variables de entorno
load_dotenv()

import uvicorn
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from regards import CCARouter

# Crea la aplicación FastAPI
app = FastAPI()

# Añade el router
app.include_router(CCARouter)

# Sirve el fichero index.html cómo estático
app.mount("/", StaticFiles(directory=".", html=True), name="static")

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
