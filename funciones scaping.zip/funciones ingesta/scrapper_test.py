import pytest
import os
from unittest.mock import patch, mock_open
from datetime import datetime

import requests
from scrapper import (
    SimpleWebScraper,
    delete_scraping_file,
)  # Assuming the provided code is in scrapper.py


# --- Fixtures ---
@pytest.fixture
def scraper():
    """Provides a fresh SimpleWebScraper instance for each test."""
    return SimpleWebScraper(delay=0)  # Set delay to 0 for faster tests


@pytest.fixture
def mock_requests_get():
    """Mocks requests.get to control HTTP responses."""
    with patch("requests.get") as mock_get:
        yield mock_get


# --- Test Cases ---


def test_read_urls_success(scraper):
    """Tests reading URLs from a valid file."""
    mock_file_content = "http://example.com/parent1\nhttp://example.com/parent2\n"
    with patch("builtins.open", mock_open(read_data=mock_file_content)):
        urls = scraper.read_urls("urls.txt")
        assert len(urls) == 2
        assert "http://example.com/parent1" in urls
        assert "http://example.com/parent2" in urls


def test_read_urls_file_not_found(scraper, capsys):
    """Tests reading URLs when the file does not exist."""
    with patch("builtins.open", side_effect=FileNotFoundError):
        urls = scraper.read_urls("non_existent_urls.txt")
        assert len(urls) == 0
        captured = capsys.readouterr()
        assert "❌ File non_existent_urls.txt not found" in captured.out


def test_read_urls_empty_file(scraper):
    """Tests reading URLs from an empty file."""
    with patch("builtins.open", mock_open(read_data="")):
        urls = scraper.read_urls("empty.txt")
        assert len(urls) == 0


def test_scrape_url_success_parent(scraper, mock_requests_get):
    """Tests successful scraping of a parent URL."""
    mock_requests_get.return_value.status_code = 200
    mock_requests_get.return_value.content = (
        "<html><head><title>Parent Title</title></head><body>"
        "<a href='/child1'>Child 1</a>"
        "<a href='http://external.com/'>External</a>"
        "Some content here."
        "</body></html>"
    )
    mock_requests_get.return_value.raise_for_status.return_value = None

    url = "http://example.com/parent"
    data = scraper.scrape_url(url, level="parent")

    assert data is not None
    assert data["url"] == url
    assert data["title"] == "Parent Title"
    assert data["level"] == "parent"
    assert "Some content here." in data["content"]
    assert len(data["child_urls"]) == 1
    assert "http://example.com/child1" in data["child_urls"]
    assert url in scraper.visited_urls  # Should be in visited_urls now
    assert url in scraper.visited_urls  # Correct check


def test_scrape_url_success_child(scraper, mock_requests_get):
    """Tests successful scraping of a child URL."""
    mock_requests_get.return_value.status_code = 200
    mock_requests_get.return_value.content = "<html><head><title>Child Title</title></head><body>Child content.</body></html>"
    mock_requests_get.return_value.raise_for_status.return_value = None

    url = "http://example.com/child1"
    data = scraper.scrape_url(url, level="child")

    assert data is not None
    assert data["url"] == url
    assert data["title"] == "Child Title"
    assert data["level"] == "child"
    assert "Child content." in data["content"]
    assert len(data["child_urls"]) == 0  # Child URLs should not look for links
    assert url in scraper.visited_urls


def test_scrape_url_http_error(scraper, mock_requests_get, capsys):
    """Tests scraping when an HTTP error occurs."""
    mock_requests_get.return_value.status_code = 404
    mock_requests_get.return_value.raise_for_status.side_effect = (
        requests.exceptions.HTTPError("Not Found")
    )

    url = "http://example.com/404"
    data = scraper.scrape_url(url)

    assert data is not None
    assert data["url"] == url
    assert "error" in data
    assert "Not Found" in data["error"]
    assert url in scraper.visited_urls
    captured = capsys.readouterr()
    assert f"⚠️  Error on {url}:" in captured.out


def test_scrape_url_connection_error(scraper, mock_requests_get, capsys):
    """Tests scraping when a connection error occurs."""
    mock_requests_get.side_effect = requests.exceptions.ConnectionError(
        "DNS lookup failed"
    )

    url = "http://bad-url.com"
    data = scraper.scrape_url(url)

    assert data is not None
    assert data["url"] == url
    assert "error" in data
    assert "DNS lookup failed" in data["error"]
    assert url in scraper.visited_urls
    captured = capsys.readouterr()
    assert f"⚠️  Error on {url}:" in captured.out


def test_scrape_url_already_visited(scraper):
    """Tests that a URL is not scraped if already visited."""
    url = "http://example.com/visited"
    scraper.visited_urls.add(url)
    data = scraper.scrape_url(url)
    assert data is None


def test_same_domain(scraper):
    """Tests the _same_domain helper method."""
    assert scraper._same_domain("http://example.com/path", "http://example.com/another")
    assert not scraper._same_domain("http://example.com", "http://anothersite.com")
    assert not scraper._same_domain(
        "http://sub.example.com", "http://example.com"
    )  # Different subdomains


def test_scrape_all_no_parent_urls(scraper, capsys):
    """Tests scrape_all when no parent URLs are provided."""
    with patch.object(scraper, "read_urls", return_value=[]):
        scraper.scrape_all()
        assert len(scraper.results) == 0
        captured = capsys.readouterr()
        # No output regarding "Starting scraping..." should be present
        assert "🚀 Starting scraping..." not in captured.out


def test_scrape_all_with_parents_and_children(scraper, mock_requests_get):
    """Tests the full scrape_all process with parent and child URLs."""
    parent_url = "http://example.com/parent"
    child_url = "http://example.com/child"

    mock_requests_get.side_effect = [
        # Response for parent_url
        mock_response(
            200,
            f"<html><head><title>Parent</title></head><body><a href='{child_url}'>Child Link</a>Parent Content</body></html>",
        ),
        # Response for child_url
        mock_response(
            200,
            "<html><head><title>Child</title></head><body>Child Content</body></html>",
        ),
    ]

    with patch.object(scraper, "read_urls", return_value=[parent_url]):
        scraper.scrape_all()

    assert len(scraper.results) == 2
    assert any(r["url"] == parent_url for r in scraper.results)
    assert any(r["url"] == child_url for r in scraper.results)
    assert parent_url in scraper.visited_urls
    assert child_url in scraper.visited_urls


def test_scrape_all_with_error_in_parent(scraper, mock_requests_get, capsys):
    """Tests scrape_all when a parent URL fails."""
    error_url = "http://example.com/error_parent"
    mock_requests_get.side_effect = requests.exceptions.RequestException("Test Error")

    with patch.object(scraper, "read_urls", return_value=[error_url]):
        scraper.scrape_all()

    assert len(scraper.results) == 1
    assert scraper.results[0]["url"] == error_url
    assert "error" in scraper.results[0]
    captured = capsys.readouterr()
    assert f"⚠️  Error on {error_url}: Test Error" in captured.out


def test_scrape_all_with_error_in_child(scraper, mock_requests_get, capsys):
    """Tests scrape_all when a child URL fails."""
    parent_url = "http://example.com/parent_with_bad_child"
    bad_child_url = "http://example.com/bad_child"

    mock_requests_get.side_effect = [
        mock_response(
            200,
            f"<html><head><title>Parent</title></head><body><a href='{bad_child_url}'>Bad Child</a>Parent Content</body></html>",
        ),
        requests.exceptions.RequestException("Child Error"),
    ]

    with patch.object(scraper, "read_urls", return_value=[parent_url]):
        scraper.scrape_all()

    assert len(scraper.results) == 2
    parent_data = next((r for r in scraper.results if r["url"] == parent_url), None)
    child_data = next((r for r in scraper.results if r["url"] == bad_child_url), None)

    assert parent_data is not None
    assert "error" not in parent_data
    assert bad_child_url in parent_data["child_urls"]

    assert child_data is not None
    assert "error" in child_data
    assert "Child Error" in child_data["error"]
    captured = capsys.readouterr()
    assert f"⚠️  Error on {bad_child_url}: Child Error" in captured.out


def test_format_output_empty_results(scraper):
    """Tests output formatting with no results."""
    output = scraper.format_output()
    assert "Pages processed: 0" in output
    assert "PARENT URLS (0)" in output
    assert "CHILD URLS (0)" in output


def test_format_output_with_data(scraper):
    """Tests output formatting with scraped data."""
    scraper.results = [
        {
            "url": "http://parent.com",
            "title": "Parent Page",
            "level": "parent",
            "content": "Parent content summary.",
            "child_urls": ["http://child1.com"],
        },
        {
            "url": "http://child1.com",
            "title": "Child Page",
            "level": "child",
            "content": "Child content summary.",
        },
        {
            "url": "http://error.com",
            "error": "Simulated error",
            "level": "parent",
        },
    ]
    output = scraper.format_output()

    assert "Pages processed: 3" in output
    assert "PARENT URLS (2)" in output
    assert "CHILD URLS (1)" in output

    assert "📁 http://parent.com" in output
    assert "Title: Parent Page" in output
    assert "Child URLs: 1" in output
    assert "Content: Parent content summary." in output

    assert "📄 http://child1.com" in output
    assert "Title: Child Page" in output
    assert "Content: Child content summary." in output

    assert "📁 http://error.com" in output
    assert "Title: No title" in output  # Default title for error


def test_save_results_new_file(scraper, tmp_path):
    """Tests saving results when the file does not exist."""
    test_file = tmp_path / "test_web_scraping.txt"
    scraper.results = [
        {
            "url": "http://new.com",
            "title": "New Page",
            "level": "parent",
            "content": "New content",
        }
    ]
    with patch("os.path.exists", return_value=False):
        with patch("builtins.open", mock_open()) as mock_file_open:
            saved = scraper.save_results(str(test_file))
            assert saved is True
            mock_file_open.assert_called_once_with(str(test_file), "w")
            handle = mock_file_open()
            assert "New content" in handle.write.call_args[0][0]


def test_save_results_no_changes(scraper, tmp_path):
    """Tests saving results when there are no changes compared to an existing file."""
    test_file = tmp_path / "test_web_scraping.txt"
    initial_content = (
        "WEB SCRAPING - 2023-01-01 12:00:00\n"
        "Pages processed: 1\n"
        "PARENT URLS (1)\n"
        "------------------------------\n"
        "\n📁 http://unchanged.com\n"
        "   Title: Unchanged Page\n"
        "   Child URLs: 0\n"
        "   Content: Unchanged content\n"
        "\n\nCHILD URLS (0)\n"
        "------------------------------"
    )
    scraper.results = [
        {
            "url": "http://unchanged.com",
            "title": "Unchanged Page",
            "level": "parent",
            "content": "Unchanged content",
        }
    ]

    with patch("os.path.exists", return_value=True):
        with patch(
            "builtins.open", mock_open(read_data=initial_content)
        ) as mock_file_open:
            saved = scraper.save_results(str(test_file))
            assert saved is False
            # Check that open was called for reading, but not for writing new content
            assert mock_file_open.call_args[0][1] == "r"
            assert mock_file_open.call_count == 1  # Only read operation


def test_save_results_with_changes(scraper, tmp_path):
    """Tests saving results when there are changes compared to an existing file."""
    test_file = tmp_path / "test_web_scraping.txt"
    initial_content = (
        "WEB SCRAPING - 2023-01-01 12:00:00\n"
        "Pages processed: 1\n"
        "PARENT URLS (1)\n"
        "------------------------------\n"
        "\n📁 http://old.com\n"
        "   Title: Old Page\n"
        "   Child URLs: 0\n"
        "   Content: Old content\n"
        "\n\nCHILD URLS (0)\n"
        "------------------------------"
    )
    scraper.results = [
        {
            "url": "http://new_and_changed.com",
            "title": "New Page",
            "level": "parent",
            "content": "New content",
        }
    ]

    with patch("os.path.exists", return_value=True):
        # First mock for reading existing file, then for writing new file
        m_open = mock_open(read_data=initial_content)
        with patch("builtins.open", m_open):
            saved = scraper.save_results(str(test_file))
            assert saved is True
            # Assert open was called twice: once for 'r' and once for 'w'
            assert m_open.call_count == 2
            assert m_open.call_args_list[0][0][1] == "r"
            assert m_open.call_args_list[1][0][1] == "w"
            handle = m_open()
            assert "New content" in handle.write.call_args[0][0]


def test_delete_scraping_file_success(tmp_path, capsys):
    """Tests successful deletion of the scraping file."""
    test_file = tmp_path / "delete_me.txt"
    test_file.write_text("some content")
    assert test_file.exists()

    result = delete_scraping_file(str(test_file))
    assert result is True
    assert not test_file.exists()
    captured = capsys.readouterr()
    assert f"🗑️  File {test_file} deleted" in captured.out


def test_delete_scraping_file_not_exists(tmp_path, capsys):
    """Tests deletion when the file does not exist."""
    test_file = tmp_path / "non_existent_file.txt"
    assert not test_file.exists()

    result = delete_scraping_file(str(test_file))
    assert result is False
    captured = capsys.readouterr()
    assert f"ℹ️  File {test_file} does not exist" in captured.out


def test_delete_scraping_file_permission_error(tmp_path, capsys):
    """Tests deletion when a permission error occurs."""
    test_file = tmp_path / "permission_denied.txt"
    test_file.write_text("content")

    # Simulate a PermissionError
    with patch("os.remove", side_effect=PermissionError("Access denied")):
        result = delete_scraping_file(str(test_file))
        assert result is False
        captured = capsys.readouterr()
        assert f"❌ Error deleting: Access denied" in captured.out


# Helper function for mocking requests responses
class mock_response:
    def __init__(self, status_code, content):
        self.status_code = status_code
        self.content = content.encode("utf-8")
        self.headers = {"Content-Type": "text/html"}  # Required for requests.Response

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.exceptions.HTTPError(f"HTTP Error {self.status_code}")

    @property
    def text(self):
        return self.content.decode("utf-8")
