import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import time
import os
from datetime import datetime


class SimpleWebScraper:
    def __init__(self, delay=0.5):
        """
        Initializes the scraper.

        Args:
            delay: Delay between requests in seconds. This is necessary to
                   prevent websites from blocking usage (e.g., due to rate limiting).
        """
        self.delay = delay
        # Set to store visited URLs to avoid redundant scraping and infinite loops
        self.visited_urls = set()
        # List to store the results of the scraping process
        self.results = []

    def read_urls(self, filename="urls.txt"):
        """
        Reads URLs from the specified file.

        Args:
            filename (str): The name of the file containing URLs, one per line.

        Returns:
            list: A list of URLs read from the file. Returns an empty list
                  if the file is not found or is empty.
        """
        try:
            with open(filename, "r") as f:
                # Read each line, strip whitespace, and filter out empty lines
                urls = [line.strip() for line in f if line.strip()]

            print(f"📋 {len(urls)} URLs loaded")
            return urls
        except FileNotFoundError:
            print(f"❌ File {filename} not found")
            return []

    def scrape_url(self, url, level="parent"):
        """
        Scrapes a single URL.

        Args:
            url (str): The URL to scrape.
            level (str): The level of the URL ('parent' or 'child'). This
                         determines whether child URLs are extracted.

        Returns:
            dict or None: A dictionary containing scraped data (url, title,
                          content, child_urls, level) or error information.
                          Returns None if the URL has already been visited.
        """
        # If the URL has already been visited, skip it to prevent re-scraping
        if url in self.visited_urls:
            return None

        # Add the current URL to the set of visited URLs
        self.visited_urls.add(url)

        try:
            # Send an HTTP GET request to the URL with a timeout and user-agent
            response = requests.get(
                url,
                timeout=10,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                },
            )
            # Raise an HTTPError for bad responses (4xx or 5xx)
            response.raise_for_status()

            # Parse the HTML content of the page using BeautifulSoup
            soup = BeautifulSoup(response.content, "html.parser")

            # Extract data: URL, title, content, and initialize child_urls
            data = {
                "url": url,
                "title": soup.title.string if soup.title else "No title",
                "level": level,
                "content": " ".join(
                    soup.stripped_strings
                ),  # TODO: the content, without limit
                "child_urls": [],
            }

            # Only look for links if it's a parent URL
            if level == "parent":
                # Find all 'a' (anchor) tags with an 'href' attribute
                links = soup.find_all("a", href=True)
                for link in links:
                    # Construct the absolute URL from the base URL and the link's href
                    absolute_url = urljoin(url, link["href"])
                    parsed = urlparse(absolute_url)

                    # Check if the link is an HTTP/HTTPS URL, on the same domain,
                    # and not already visited
                    if (
                        parsed.scheme in ["http", "https"]
                        and self._same_domain(url, absolute_url)
                        and absolute_url not in self.visited_urls
                    ):
                        data["child_urls"].append(absolute_url)

            return data

        except requests.exceptions.RequestException as e:
            # Catch specific requests exceptions (HTTPError, ConnectionError, Timeout, etc.)
            print(f"⚠️  Error on {url}: {e}")
            return {"url": url, "error": str(e), "level": level}
        except Exception as e:
            # Catch any other unexpected errors during scraping
            print(f"⚠️  Error on {url}: {e}")
            return {"url": url, "error": str(e), "level": level}

    def _same_domain(self, url1, url2):
        """
        Checks if two URLs belong to the same domain.

        Args:
            url1 (str): The first URL.
            url2 (str): The second URL.

        Returns:
            bool: True if domains are the same, False otherwise.
        """
        return urlparse(url1).netloc == urlparse(url2).netloc

    def scrape_all(self, urls_file="urls.txt"):
        """
        Executes the entire scraping process.

        Reads parent URLs, scrapes them, and then scrapes their child URLs
        recursively (up to one level deep for children).
        """

        # Read the URLs from the file
        parent_urls = self.read_urls(urls_file)
        if not parent_urls:
            # If no parent URLs are found, there's nothing to scrape
            return

        print(f"🚀 Starting scraping...")

        # Process each URL found in the file
        for parent_url in parent_urls:
            print(f"\n📍 Processing: {parent_url}")

            # Scrape the parent URL
            parent_data = self.scrape_url(parent_url, "parent")
            if parent_data:
                self.results.append(parent_data)

                # Scrape child URLs found on the parent page
                for child_url in parent_data.get("child_urls", []):
                    # Introduce a delay to be respectful to the website's server
                    # and avoid getting blocked
                    time.sleep(self.delay)

                    # Scrape and store the child URLs
                    child_data = self.scrape_url(child_url, "child")
                    if child_data:
                        self.results.append(child_data)

            # Introduce a delay after processing each parent URL and its children
            time.sleep(self.delay)

        print(f"\n✅ Completed: {len(self.results)} pages processed")

    def format_output(self):
        """
        Formats the scraped results into a readable string for file saving.

        Returns:
            str: A multi-line string containing the formatted scraping results,
                 categorized by parent and child URLs, including titles,
                 content summaries, and child URL counts.
        """
        lines = []
        lines.append("=" * 70)
        lines.append(f"WEB SCRAPING - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("=" * 70)
        lines.append(f"\nPages processed: {len(self.results)}\n")

        # Separate parent URLs from the results
        parents = [r for r in self.results if r.get("level") == "parent"]
        lines.append(f"\nPARENT URLS ({len(parents)})")
        lines.append("-" * 30)

        for data in parents:
            lines.append(f"\n📁 {data['url']}")
            lines.append(f"   Title: {data.get('title', 'No title')}")
            if "error" not in data:
                lines.append(f"   Child URLs: {len(data.get('child_urls', []))}")
                lines.append(f"   Content: {data['content']}")  # Full content

        # Separate child URLs from the results
        children = [r for r in self.results if r.get("level") == "child"]
        lines.append(f"\n\nCHILD URLS ({len(children)})")
        lines.append("-" * 30)

        for data in children:
            lines.append(f"\n📄 {data['url']}")
            lines.append(f"   Title: {data.get('title', 'No title')}")
            if "error" not in data:
                lines.append(f"   Content: {data['content']}")  # Full content

        return "\n".join(lines)

    def save_results(self, filename="web_scraping.txt"):
        """
        Compares the current scraping results with previous ones stored in a file.
        If there are no changes, the existing file is kept. Otherwise, the new
        results are saved, overwriting the old file.

        Args:
            filename (str): The name of the file to save the results to.

        Returns:
            bool: True if new results were saved, False if no changes were detected.
        """
        new_content = self.format_output()

        # Check if the file exists to compare content
        if os.path.exists(filename):
            with open(filename, "r") as f:
                old_content = f.read()

            # Compare processed URLs to determine if there are significant changes
            old_urls = [
                line.strip()
                for line in old_content.split("\n")
                if line.strip().startswith("📁") or line.strip().startswith("📄")
            ]
            new_urls = [
                line.strip()
                for line in new_content.split("\n")
                if line.strip().startswith("📁") or line.strip().startswith("📄")
            ]

            if set(old_urls) == set(new_urls):
                print(f"ℹ️  No changes, keeping existing file")
                return False

        # If file doesn't exist or changes are detected, save the new content
        with open(filename, "w") as f:
            f.write(new_content)
        print(f"💾 Results saved to {filename}")
        return True


def delete_scraping_file(filename="web_scraping.txt"):
    """
    Deletes the specified scraping results file.

    Args:
        filename (str): The name of the file to delete.

    Returns:
        bool: True if the file was successfully deleted, False otherwise.
    """
    try:
        if os.path.exists(filename):
            os.remove(filename)
            print(f"🗑️  File {filename} deleted")
            return True
        else:
            print(f"ℹ️  File {filename} does not exist")
            return False
    except Exception as e:
        print(f"❌ Error deleting: {e}")
        return False


if __name__ == "__main__":
    # Create an instance of the SimpleWebScraper
    scraper = SimpleWebScraper()
    # Execute the full scraping process
    scraper.scrape_all()
    # Save the scraped results to a file
    scraper.save_results()
