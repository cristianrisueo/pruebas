"""
regards.py

Backend FastAPI para Voicebot (OpenAI Realtime VAD).

- Control de turnos: el backend nunca reenvía audio mientras el asistente habla.
- Reconexión automática si OpenAI cierra el WebSocket (cód. 1000 OK).
- Verificación de variables de entorno (API_KEY, WS_URL) dentro de open_openai_ws().
- Transcribe y valida el contenido del audio ANTES de enviarlo a OpenAI.
- Filtrado de contenido prohibido: no envía a OpenAI audio con palabras prohibidas.
"""

import asyncio
import base64
import json
import logging
import os
import ssl
import time
from typing import Dict, List, Optional, Tuple, Union

import websockets
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from websockets.exceptions import ConnectionClosedOK
import httpx


# * Configuración: Loggers, env vars, system message y voz, listado de clientes y router


logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

API_KEY = os.getenv("API_KEY")
OPENAI_WS_URL = os.getenv("WS_URL")

SYSTEM_MESSAGE = "Responde siempre en español, breve y claro."
VOICE = "ash"

CONNECTED_CLIENTS: List[WebSocket] = []
CCARouter = APIRouter()


# * Helper functions


async def process_transcription(text: str) -> bool:
    """
    Procesa la transcripción del audio del usuario.
    Detecta contenido prohibido y decide si el audio debe enviarse a OpenAI.

    Args:
        text: El texto transcrito del audio del usuario

    Returns:
        bool: True si el audio es seguro, False si contiene palabras prohibidas
    """
    logger.info(f"Transcripción del usuario: {text}")

    # Detectar palabras prohibidas
    if "asesinar" in text.lower():
        logger.warning(f"Contenido prohibido detectado en transcripción: '{text}'")
        return False

    return True


async def send_error_to_client(websocket: WebSocket, message: str):
    """
    Envía un mensaje de error al cliente.

    Args:
        websocket: El websocket del cliente
        message: El mensaje de error
    """
    error_response = {
        "type": "error",
        "error": {"message": message, "code": "content_filtered"},
    }

    try:
        await websocket.send_text(json.dumps(error_response))
        logger.info(f"Mensaje de error enviado al cliente: {message}")
    except Exception as e:
        logger.error(f"Error al enviar mensaje de error al cliente: {e}")


async def transcribe_audio(audio_chunks: List[str]) -> Optional[str]:
    """
    Transcribe el audio acumulado utilizando OpenAI Whisper API.
    Recibe una lista de chunks de audio en base64, los convierte a WAV y devuelve el texto transcrito.
    """
    if not audio_chunks:
        return None

    try:
        from pydub import AudioSegment
        import numpy as np
        import io

        # Parámetros del audio PCM16
        RATE = 26000  # Hz - debe coincidir con el frontend
        CHANNELS = 1  # Mono
        WIDTH = 2  # 16 bits = 2 bytes

        # Combinamos todos los chunks de audio
        all_audio_binary = b"".join([base64.b64decode(chunk) for chunk in audio_chunks])

        # Convertimos bytes a array numpy
        audio_array = np.frombuffer(all_audio_binary, dtype=np.int16)

        # Creamos un objeto AudioSegment usando numpy array
        audio_segment = AudioSegment(
            audio_array.tobytes(),
            frame_rate=RATE,
            sample_width=WIDTH,
            channels=CHANNELS,
        )

        # Guardamos el audio como WAV en un archivo temporal
        temp_filename = f"temp_audio_{int(time.time())}.wav"
        audio_segment.export(temp_filename, format="wav")

        logger.info(
            f"Audio convertido a WAV ({len(audio_array)} muestras, duración: {len(audio_segment)/1000:.2f}s)"
        )

        try:
            async with httpx.AsyncClient(
                timeout=30.0
            ) as client:  # Aumentamos el timeout
                with open(temp_filename, "rb") as f:
                    response = await client.post(
                        "https://api.openai.com/v1/audio/transcriptions",
                        headers={"Authorization": f"Bearer {API_KEY}"},
                        files={"file": (temp_filename, f, "audio/wav")},
                        data={"model": "whisper-1", "language": "es"},
                    )

                if response.status_code == 200:
                    result = response.json()
                    logger.info(
                        f"Transcripción exitosa: {len(result.get('text', ''))} caracteres"
                    )
                    return result.get("text")
                else:
                    logger.error(
                        f"Error al transcribir: {response.status_code} - {response.text}"
                    )
        finally:
            # Limpiamos el archivo temporal
            try:
                os.remove(temp_filename)
            except Exception as e:
                logger.error(f"Error al eliminar archivo temporal: {e}")

    except Exception as e:
        logger.error(f"Error en transcripción: {str(e)}")
        import traceback

        logger.error(traceback.format_exc())

    return None


async def forward_to_clients(raw: str):
    """
    Envía un mensaje JSON recibido de OpenAI a todos los navegadores conectados.
    Ignora silenciosamente los clientes que ya cerraron.
    """

    for client in list(CONNECTED_CLIENTS):
        try:
            await client.send_text(raw)
        except Exception:
            pass


async def send_session_config(ws):
    """
    Envía al WebSocket de OpenAI el mensaje `session.update` con:
    - instrucciones de sistema
    - parámetros de VAD basados en server_vad
    - configuración de voz y formatos de audio
    """

    await ws.send(
        json.dumps(
            {
                "type": "session.update",
                "session": {
                    "instructions": SYSTEM_MESSAGE,
                    "turn_detection": {
                        "type": "server_vad",
                        "threshold": 0.5,
                        "prefix_padding_ms": 300,
                        "silence_duration_ms": 500,
                    },
                    "voice": VOICE,
                    "input_audio_format": "pcm16",
                    "output_audio_format": "pcm16",
                    "modalities": ["text", "audio"],
                },
            }
        )
    )

    logger.info("→ session.update enviada")


# Mover process_user_audio al ámbito global para que esté disponible en todos los contextos
async def process_user_audio(audio_chunks, client_websocket, openai_websocket=None):
    """
    Procesa el audio del usuario: transcribe, verifica contenido y envía a OpenAI si es seguro.

    Args:
        audio_chunks: Lista de chunks de audio en base64
        client_websocket: WebSocket del cliente web
        openai_websocket: WebSocket de OpenAI (opcional)

    Returns:
        bool: True si el proceso se completó correctamente, False en caso contrario
    """
    # Transcribimos el audio
    transcription = await transcribe_audio(audio_chunks)

    if transcription:
        # Procesamos la transcripción y verificamos si es contenido permitido
        is_safe = await process_transcription(transcription)

        if not is_safe:
            # Si contiene contenido prohibido, no enviamos nada a OpenAI
            logger.warning("Audio no enviado a OpenAI debido a contenido prohibido")
            await send_error_to_client(
                client_websocket,
                "Contenido prohibido detectado. Por favor, reformule su mensaje.",
            )
            return False

        # Si es seguro y tenemos conexión con OpenAI, enviamos el audio
        if openai_websocket:
            logger.info("Contenido validado como seguro, enviando a OpenAI")
            try:
                # Enviamos todos los chunks de audio
                for chunk in audio_chunks:
                    await openai_websocket.send(
                        json.dumps(
                            {
                                "type": "input_audio_buffer.append",
                                "audio": chunk,
                            }
                        )
                    )

                # Señalamos el fin del audio
                await openai_websocket.send(
                    json.dumps({"type": "input_audio_buffer.stop"})
                )
                return True

            except ConnectionClosedOK:
                logger.error("Conexión con OpenAI cerrada durante el envío de audio")
                return False
            except Exception as e:
                logger.error(f"Error al enviar audio a OpenAI: {e}")
                return False
        else:
            logger.warning("No hay conexión disponible con OpenAI para enviar el audio")
            return False
    else:
        logger.warning("No se pudo obtener transcripción del audio del usuario")
        return False


async def receive_from_openai(ws, state: Dict):
    """
    Bucle asíncrono que recibe todos los eventos de OpenAI.

    - Cuando detecta el inicio de respuesta, marca `awaiting_response` y envía
      `input_audio_buffer.stop` para cortar posibles restos en cola.
    - Al final (`response.audio.end` / `response.done`) libera el flag y
      procesa cualquier audio del usuario almacenado en `state["buffer"]`.
    - Reenvía todos los mensajes al/los cliente/s vía forward_to_clients().
    """

    try:
        async for raw in ws:
            msg = json.loads(raw)
            t = msg.get("type", "")

            # Inicio del turno del bot
            if t in ("response.start", "response.audio.start"):
                state["awaiting_response"] = True
                await ws.send(json.dumps({"type": "input_audio_buffer.stop"}))

            # Fin de turno del bot
            if t in ("response.audio.end", "response.done"):
                state["awaiting_response"] = False

                # Procesa el audio del usuario que se almacenó mientras el bot hablaba
                if state["buffer"]:
                    logger.info(
                        f"Procesando {len(state['buffer'])} chunks de audio almacenados durante respuesta"
                    )

                    # Guardamos una copia del buffer y lo limpiamos
                    buffered_audio = state["buffer"].copy()
                    state["buffer"] = []

                    # Intentamos encontrar un cliente válido para procesar el audio
                    from weakref import ref

                    websockets_refs = [ref(client) for client in CONNECTED_CLIENTS]

                    for client_ref in websockets_refs:
                        client = client_ref()
                        if client:
                            asyncio.create_task(
                                process_user_audio(buffered_audio, client, ws)
                            )
                            break

            await forward_to_clients(raw)

    # Cierre "normal" → marcamos para reconexión
    except ConnectionClosedOK:
        state["closed"] = True
        logger.info("OpenAI cerró la sesión (1000 OK)")

    # Cierre por errores
    except Exception as e:
        state["closed"] = True
        logger.error(f"receive_from_openai: {e}")


async def open_openai_ws(state: Dict):
    """
    Abre (o reabre) un WebSocket con la API Realtime.

    Comprueba aquí las variables de entorno para permitir
    importación del módulo sin romper el servidor si faltan.
    """

    # Comprueba que existan las env vars
    if not API_KEY or not OPENAI_WS_URL:
        raise RuntimeError("Faltan variables de entorno API_KEY o WS_URL")

    # TODO: SSL sin certificado, en producción no puede estar
    ssl_ctx = ssl.create_default_context()
    ssl_ctx.check_hostname = False
    ssl_ctx.verify_mode = ssl.CERT_NONE

    # Headers de conexión
    headers = {"Authorization": f"Bearer {API_KEY}", "OpenAI-Beta": "realtime=v1"}

    # Conexión por websocket a OpenAI
    ws = await websockets.connect(
        OPENAI_WS_URL,
        extra_headers=headers,
        ssl=ssl_ctx,
        ping_interval=20,
        ping_timeout=20,
        max_size=None,
    )

    # Envía config inicial y lanza task de recepción
    await send_session_config(ws)

    state.update({"awaiting_response": False, "closed": False})
    asyncio.create_task(receive_from_openai(ws, state))

    # Imprime mensaje de conexión y devuelve la conexión por ws
    logger.info("✅ WebSocket OpenAI conectado")
    return ws


# * Endpoints


@CCARouter.websocket("/web-client")
async def websocket_endpoint(websocket: WebSocket):
    """
    - Acepta conexiones WebSocket del navegador
    - Conecta (o reconecta) con OpenAI mediante websocket
    - Puentea audio y eventos, respetando el control de turno
    - Intercepta y transcribe el audio del usuario antes de enviarlo a OpenAI
    - Filtra contenido prohibido y envía errores al cliente cuando corresponda
    """

    # Acepta la conexión recibida y la añade a la lista
    await websocket.accept()
    CONNECTED_CLIENTS.append(websocket)

    logger.info(f"Cliente conectado ({len(CONNECTED_CLIENTS)})")

    # Crea un state de la sesión para la conexión con openai por ws
    state = {
        "awaiting_response": False,  # Turno del bot
        "buffer": [],  # audio del usuario almacenado
        "closed": False,  # WS con OpenAI está cerrado
        "current_user_audio": [],  # Acumula el audio del usuario para transcripción
        "last_audio_time": time.time(),  # Tiempo del último chunk de audio recibido
        "vad_silence_timeout": 1.0,  # Segundos de silencio para considerar fin de turno
    }

    # Realiza la conexión por ws con openai pasando el state creado
    openai_ws = await open_openai_ws(state)

    # Tarea para detectar el final del turno del usuario por silencio
    async def check_user_turn_end():
        while True:
            await asyncio.sleep(0.1)  # Comprobamos cada 100ms

            # Solo procesamos si tenemos audio acumulado y no está respondiendo el bot
            if state["current_user_audio"] and not state["awaiting_response"]:
                time_since_last_audio = time.time() - state["last_audio_time"]

                # Si ha pasado el tiempo de silencio y tenemos suficiente audio (al menos 0.5 segundos)
                if (
                    time_since_last_audio > state["vad_silence_timeout"]
                    and len(state["current_user_audio"]) > 5
                ):  # Asumiendo chunks de ~100ms

                    # Transcribimos lo acumulado hasta ahora
                    logger.info(
                        f"Detectado fin de turno del usuario ({len(state['current_user_audio'])} chunks), transcribiendo..."
                    )

                    # Tomamos el audio acumulado y limpiamos el buffer para evitar procesarlo dos veces
                    audio_to_transcribe = state["current_user_audio"].copy()
                    state["current_user_audio"] = []

                    # Transcribimos (en una tarea separada para no bloquear)
                    asyncio.create_task(
                        process_user_audio(audio_to_transcribe, websocket, openai_ws)
                    )

    # Iniciamos la tarea de detección de fin de turno
    asyncio.create_task(check_user_turn_end())

    try:
        while True:
            # Se recoge el mensaje del cliente
            data = await websocket.receive_text()
            msg = json.loads(data)

            # Reconecta si OpenAI se había cerrado
            if state["closed"]:
                try:
                    openai_ws = await open_openai_ws(state)
                except Exception as e:
                    logger.error(f"Reconexión fallida: {e}")
                    continue

            # Si el mensaje es de tipo audio
            if msg.get("type") == "audio_data":
                # Actualizamos el tiempo del último audio recibido
                state["last_audio_time"] = time.time()

                # Guardamos el audio para transcribir posteriormente
                if not state["awaiting_response"]:
                    state["current_user_audio"].append(msg["audio"])

                # Si el bot está hablando, lo almacena; si no, lo envía directo
                if state["awaiting_response"]:
                    state["buffer"].append(msg["audio"])
                else:
                    try:
                        await openai_ws.send(
                            json.dumps(
                                {
                                    "type": "input_audio_buffer.append",
                                    "audio": msg["audio"],
                                }
                            )
                        )
                    except ConnectionClosedOK:
                        state["closed"] = True

            # Si recibimos una señal explícita de fin de audio del usuario
            elif msg.get("type") == "input_audio_buffer.stop":
                # Transcribimos si hay audio acumulado
                if state["current_user_audio"]:
                    logger.info(
                        f"Transcribiendo audio del usuario (stop explícito, {len(state['current_user_audio'])} chunks)..."
                    )

                    # Tomamos el audio acumulado y limpiamos el buffer
                    audio_to_transcribe = state["current_user_audio"].copy()
                    state["current_user_audio"] = []

                    # Procesamos en una tarea separada
                    asyncio.create_task(
                        process_user_audio(audio_to_transcribe, websocket, openai_ws)
                    )

                # Enviamos la señal de stop a OpenAI
                try:
                    await openai_ws.send(
                        json.dumps({"type": "input_audio_buffer.stop"})
                    )
                except ConnectionClosedOK:
                    state["closed"] = True

    # Controla el cierre de websocket por parte del cliente
    except WebSocketDisconnect:
        logger.info("Cliente navegador desconectado")

    # Cierra la conexión por websocket y la conexión por ws con openai
    finally:
        CONNECTED_CLIENTS.remove(websocket)

        try:
            await openai_ws.close()
        except Exception:
            pass
