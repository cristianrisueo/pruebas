# 2.5 Quick Start Guide Expanded

## 1. Introduction

This framework allows you to create and manage intelligent agents based on LLM (Large Language Models) that can process user requests and provide automated responses using specialized tools. The framework follows a hexagonal architecture that separates business logic from external interfaces.

## 2. Framework Structure

### 2.1 Folder Organization

```
src/
├── app/                 # Main application folder (do not modify)
├── agent_X/             # Specific agent folder
│   ├── logic.py         # Implementation of tools defined for the agent
│   ├── logic_config.yml # Agent configuration
│   ├── input/           # Directory required by hexagonal architecture
│   ├── output/          # Directory required by hexagonal architecture
│   ├── extra_config.py  # Additional configurations (optional)
│   └── tools/           # Agent tools (optional)
│       ├── tool_1.py
│       ├── tool_2.py
│       └── utils/       # Utility functions for tools (optional)
└── my_agent/            # Example of another agent
```

### 2.2 Required Elements

For each agent, the following elements are mandatory:

- **logic.py**: Implementation of the tools defined for the agent
- **logic_config.yml**: Agent configuration file
- **input/**: Directory required by the hexagonal architecture
- **output/**: Directory required by the hexagonal architecture

## 3. Agent Configuration

### 3.1 `logic_config.yml` File

This file defines the main configuration of the agent:

```yaml
name: "Agent name"
role: "SPECIALIST" # Must be "SPECIALIST" or "SUPERVISOR" in uppercase
llm_model_name: "model_name" # LLM model for formatting final responses
system_prompt: |
  # Detailed prompt that defines the agent's behavior
  # Must include information about available tools and workflow
```

#### 3.1.1 Role Types

- **SPECIALIST**: Normal agent that processes requests and uses specific tools
- **SUPERVISOR**: Orchestrator agent that can coordinate other agents

### 3.2 `logic.py` File

This file implements the tools defined for the agent. The main class is `Logic` and the tools are defined as a parameter within the `super().__init__()` call:

```python
class Logic(SuperClass):
    def __init__(self):
        super().__init__(
            # Other constructor parameters
            tools=[
                # List of tools the agent can use
                Tool1(),
                Tool2()
            ]
        )
```

## 4. Framework Operation

The operational flow of the framework is as follows:

1. The user makes a request to the system
2. The agent receives the request
3. The agent, based on its `system_prompt`, determines which tool to use
4. The selected tool executes its logic and produces a response
5. The agent processes the response using the LLM model specified in `llm_model_name`
6. The agent returns the processed response to the user

### 4.1 Request Flow Diagram

![alt text](request-flow-diagram.svg)

In this diagram:

- The request enters through the API endpoint
- The agent receives the request and analyzes which tool to use according to its system_prompt
- The appropriate tool is selected and executed
- The tool's result is processed with the LLM model defined in the agent
- The processed response is returned to the user

This flow allows for a clear separation between request reception, logical processing, and response generation, following the principles of the hexagonal architecture implemented in the framework.

## 5. Tool Development

### 5.1 Tool Structure

Tools can be organized freely within the agent's folder, although it is recommended to follow a consistent structure:

```
agent_X/
├── tools/
│   ├── tool_1.py
│   ├── tool_2.py
│   └── utils/           # Utility functions shared by tools
└── extra_config.py      # Additional configurations if needed
```

### 5.2 Implementation Freedom

The developer has freedom to implement tools and utility functions as needed. This includes:

- Using different LLM models for different tools
- Creating custom folder structures within the agent folder
- Implementing custom logic in each tool

## 6. LLM Model Integration

### 6.1 Main Model

The LLM model specified in `llm_model_name` is used exclusively for:

- Processing the response returned by tools
- Formatting the final response that will be delivered to the user

### 6.2 Additional Models

For internal tools or utility functions, different LLM models can be used:

```python
# Example in extra_config.py
from langchain.chat_models import AzureChatOpenAI
import os
from dotenv import load_dotenv

load_dotenv()

# Configuration of an additional LLM model
azure_llm = AzureChatOpenAI(
    openai_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    openai_api_base=os.getenv("AZURE_OPENAI_API_BASE"),
    openai_api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
    temperature=0.7
)
```

## 7. Importance of the System Prompt

The `system_prompt` in `logic_config.yml` is **extremely important** as it completely defines the agent's behavior. It must include:

- Detailed description of the agent's role and responsibilities
- List of available tools and when to use them
- Workflow the agent should follow
- Expected response format
- Agent limitations or restrictions

The agent acts completely automatically based on this prompt, so it must be as detailed and specific as possible.

## 8. Implementation Example

Below is a simplified implementation example:

### 8.1 Folder Structure

```
src/
└── my_agent/
    ├── logic.py
    ├── logic_config.yml
    ├── input/
    ├── output/
    ├── extra_config.py
    └── tools/
        ├── search_tool.py
        ├── calculation_tool.py
        └── utils/
            ├── text_processor.py
            └── api_connector.py
```

### 8.2 Agent Configuration

```yaml
# logic_config.yml
name: "Information Assistant"
role: "SPECIALIST"
llm_model_name: "gpt-4"
system_prompt: |
  You are a specialized information assistant that helps users find and process information.

  You have access to the following tools:
  1. search_tool: Use this tool when the user requests information about a specific topic.
  2. calculation_tool: Use this tool when the user needs to perform mathematical calculations or numerical analysis.

  Workflow:
  1. Analyze the user's request to determine which tool to use.
  2. Use the appropriate tool to process the request.
  3. Formulate a clear and concise response based on the tool's results.
  4. If the request cannot be processed by any of the available tools, inform the user of the limitations.
```

### 8.3 Agent Logic

```python
# logic.py
from SuperClass import SuperAgent  # Import base class
from tools.search_tool import SearchTool
from tools.calculation_tool import CalculationTool

class Logic(SuperAgent):
    def __init__(self):
        super().__init__(
            # Other parameters needed for initialization
            tools=[
                SearchTool(),
                CalculationTool()
            ]
        )
```

### 8.4 Tool Implementation

```python
# tools/search_tool.py
class SearchTool:
    def __init__(self):
        self.name = "search_tool"

    def execute(self, query):
        # Implementation of search logic
        # ...
        return results
```

### 8.5 Additional Configuration

```python
# extra_config.py
from langchain.chat_models import AzureChatOpenAI
import os
from dotenv import load_dotenv

load_dotenv()

# Additional LLM model for internal use in tools
azure_llm = AzureChatOpenAI(
    openai_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    openai_api_base=os.getenv("AZURE_OPENAI_API_BASE"),
    openai_api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
    temperature=0.7
)
```

## 9. Summary

This framework provides a flexible yet coherent structure for creating LLM-based agents that can process user requests using specialized tools. The key points to remember are:

1. Each agent must have the `logic.py` and `logic_config.yml` files
2. The `system_prompt` is crucial and must be detailed
3. Developers have freedom to implement tools and utility functions
4. The LLM model specified in `llm_model_name` is used only to format final responses
5. Different LLM models can be used for different internal tools

The underlying hexagonal architecture ensures a clear separation between business logic and external interfaces, facilitating system extensibility and maintenance.
