# Documentación del Framework de Agentes

## 1. Introducción

Este framework permite crear y gestionar agentes inteligentes basados en LLM (Large Language Models) que pueden procesar solicitudes de usuarios y proporcionar respuestas automáticas utilizando herramientas especializadas. El framework sigue una arquitectura hexagonal que separa la lógica de negocio de las interfaces externas.

## 2. Estructura del Framework

### 2.1 Organización de Carpetas

```
src/
├── app/                 # Carpeta de la aplicación principal (no modificar)
├── agent_X/             # Carpeta de un agente específico
│   ├── logic.py         # Implementación de las tools definidas para el agente
│   ├── logic_config.yml # Configuración del agente
│   ├── input/           # Directorio requerido por arquitectura hexagonal
│   ├── output/          # Directorio requerido por arquitectura hexagonal
│   ├── extra_config.py  # Configuraciones adicionales (opcional)
│   └── tools/           # Herramientas del agente (opcional)
│       ├── tool_1.py
│       ├── tool_2.py
│       └── utils/       # Funciones de utilidad para las tools (opcional)
└── my_agent/            # Ejemplo de otro agente
```

### 2.2 Elementos Obligatorios

Para cada agente, los siguientes elementos son obligatorios:

- **logic.py**: Implementación principal del agente
- **logic_config.yml**: Archivo de configuración del agente
- **input/**: Directorio requerido por la arquitectura hexagonal
- **output/**: Directorio requerido por la arquitectura hexagonal

## 3. Configuración del Agente

### 3.1 Archivo `logic_config.yml`

Este archivo define la configuración principal del agente:

```yaml
name: "Nombre del agente"
role: "SPECIALIST" # Debe ser "SPECIALIST" o "SUPERVISOR" en mayúsculas
llm_model_name: "nombre_del_modelo" # Modelo LLM para formatear respuestas finales
system_prompt: |
  # Prompt detallado que define el comportamiento del agente
  # Debe incluir información sobre las herramientas disponibles y el flujo de trabajo
```

#### 3.1.1 Tipos de Roles

- **SPECIALIST**: Agente normal que procesa solicitudes y utiliza herramientas específicas
- **SUPERVISOR**: Agente orquestador que puede coordinar a otros agentes

### 3.2 Archivo `logic.py`

En este archivo se implementan las tools definidas para el agente. La clase principal es `Logic` y las tools se definen como un parámetro dentro de la llamada a `super().__init__()`:

```python
class Logic(SuperClass):
    def __init__(self):
        super().__init__(
            # Otros parámetros del constructor
            tools=[
                # Lista de herramientas que el agente puede utilizar
                Tool1(),
                Tool2()
            ]
        )
```

## 4. Funcionamiento del Framework

El flujo de operación del framework es el siguiente:

1. El usuario realiza una petición al sistema
2. El agente recibe la petición
3. El agente, basándose en su `system_prompt`, determina qué herramienta utilizar
4. La herramienta seleccionada ejecuta su lógica y produce una respuesta
5. El agente procesa la respuesta utilizando el modelo LLM especificado en `llm_model_name`
6. El agente devuelve la respuesta procesada al usuario

### 4.1 Diagrama de Flujo de la Petición

![alt text](request-flow-diagram.svg)

En este diagrama:

- La petición ingresa a través del endpoint de la API
- El agente recibe la petición y analiza qué herramienta utilizar según su system_prompt
- Se selecciona y ejecuta la herramienta apropiada
- El resultado de la herramienta se procesa con el modelo LLM definido en el agente
- La respuesta procesada se devuelve al usuario

Este flujo permite una separación clara entre la recepción de la petición, el procesamiento lógico y la generación de respuestas, siguiendo los principios de la arquitectura hexagonal implementada en el framework.

## 5. Desarrollo de Herramientas (Tools)

### 5.1 Estructura de Herramientas

Las herramientas pueden organizarse libremente dentro de la carpeta del agente, aunque se recomienda seguir una estructura consistente:

```
agent_X/
├── tools/
│   ├── tool_1.py
│   ├── tool_2.py
│   └── utils/           # Funciones de utilidad compartidas por las herramientas
└── extra_config.py      # Configuraciones adicionales si son necesarias
```

### 5.2 Libertad de Implementación

El desarrollador tiene libertad para implementar las herramientas y funciones de utilidad según sea necesario. Esto incluye:

- Utilizar diferentes modelos LLM para diferentes herramientas
- Crear estructuras de carpetas personalizadas dentro de la carpeta del agente
- Implementar lógica personalizada en cada herramienta

## 6. Integración con Modelos LLM

### 6.1 Modelo Principal

El modelo LLM especificado en `llm_model_name` se utiliza exclusivamente para:

- Procesar la respuesta devuelta por las herramientas
- Formatear la respuesta final que se entregará al usuario

### 6.2 Modelos Adicionales

Para las herramientas internas o funciones de utilidad, se pueden utilizar diferentes modelos LLM:

```python
# Ejemplo en extra_config.py
from langchain.chat_models import AzureChatOpenAI
import os
from dotenv import load_dotenv

load_dotenv()

# Configuración de un modelo LLM adicional
azure_llm = AzureChatOpenAI(
    openai_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    openai_api_base=os.getenv("AZURE_OPENAI_API_BASE"),
    openai_api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
    temperature=0.7
)
```

## 7. Importancia del System Prompt

El `system_prompt` en `logic_config.yml` es **extremadamente importante** ya que define completamente el comportamiento del agente. Debe incluir:

- Descripción detallada del rol y responsabilidades del agente
- Lista de herramientas disponibles y cuándo utilizarlas
- Flujo de trabajo que debe seguir el agente
- Formato esperado de las respuestas
- Limitaciones o restricciones del agente

El agente actúa de forma completamente automática basándose en este prompt, por lo que debe ser lo más detallado y específico posible.

## 8. Ejemplo de Implementación

A continuación se muestra un ejemplo simplificado de implementación:

### 8.1 Estructura de Carpetas

```
src/
└── my_agent/
    ├── logic.py
    ├── logic_config.yml
    ├── input/
    ├── output/
    ├── extra_config.py
    └── tools/
        ├── search_tool.py
        ├── calculation_tool.py
        └── utils/
            ├── text_processor.py
            └── api_connector.py
```

### 8.2 Configuración del Agente

```yaml
# logic_config.yml
name: "Asistente de Información"
role: "SPECIALIST"
llm_model_name: "gpt-4"
system_prompt: |
  Eres un asistente de información especializado que ayuda a los usuarios a encontrar y procesar información.

  Tienes acceso a las siguientes herramientas:
  1. search_tool: Utiliza esta herramienta cuando el usuario solicite información sobre un tema específico.
  2. calculation_tool: Utiliza esta herramienta cuando el usuario necesite realizar cálculos matemáticos o análisis numéricos.

  Flujo de trabajo:
  1. Analiza la solicitud del usuario para determinar qué herramienta utilizar.
  2. Utiliza la herramienta adecuada para procesar la solicitud.
  3. Formula una respuesta clara y concisa basada en los resultados de la herramienta.
  4. Si la solicitud no puede ser procesada por ninguna de las herramientas disponibles, informa al usuario de las limitaciones.
```

### 8.3 Lógica del Agente

```python
# logic.py
from SuperClass import SuperAgent  # Importación de la clase base
from tools.search_tool import SearchTool
from tools.calculation_tool import CalculationTool

class Logic(SuperAgent):
    def __init__(self):
        super().__init__(
            # Otros parámetros necesarios para la inicialización
            tools=[
                SearchTool(),
                CalculationTool()
            ]
        )
```

### 8.4 Implementación de una Herramienta

```python
# tools/search_tool.py
class SearchTool:
    def __init__(self):
        self.name = "search_tool"

    def execute(self, query):
        # Implementación de la lógica de búsqueda
        # ...
        return results
```

### 8.5 Configuración Adicional

```python
# extra_config.py
from langchain.chat_models import AzureChatOpenAI
import os
from dotenv import load_dotenv

load_dotenv()

# Modelo LLM adicional para uso interno en herramientas
azure_llm = AzureChatOpenAI(
    openai_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    openai_api_base=os.getenv("AZURE_OPENAI_API_BASE"),
    openai_api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
    temperature=0.7
)
```

## 9. Resumen

Este framework proporciona una estructura flexible pero coherente para crear agentes basados en LLM que pueden procesar solicitudes de usuarios utilizando herramientas especializadas. Los puntos clave a recordar son:

1. Cada agente debe tener los archivos `logic.py` y `logic_config.yml`
2. El `system_prompt` es crucial y debe ser detallado
3. Los desarrolladores tienen libertad para implementar herramientas y funciones de utilidad
4. El modelo LLM especificado en `llm_model_name` se utiliza solo para formatear respuestas finales
5. Se pueden utilizar diferentes modelos LLM para diferentes herramientas internas

La arquitectura hexagonal subyacente garantiza una separación clara entre la lógica de negocio y las interfaces externas, lo que facilita la extensibilidad y el mantenimiento del sistema.
