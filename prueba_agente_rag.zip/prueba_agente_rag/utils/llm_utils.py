from langchain_openai import ChatOpenAI
from config import OPENAI_API_KEY, MODEL_NAME


def enhance_markdown_with_llm(text: str, document_type: str) -> str:
    """
    Usa el LLM para convertir texto extraído a formato Markdown estructurado.

    Args:
        text: Texto extraído del documento (principalmente sin formato)
        document_type: Tipo de documento (PDF, DOCX, PPTX, XLSX)

    Returns:
        Texto convertido a formato Markdown correcto
    """

    llm = ChatOpenAI(
        openai_api_key=OPENAI_API_KEY, model_name=MODEL_NAME, temperature=0
    )

    # Instrucciones específicas para la conversión a Markdown
    base_instructions = """
    CONVIERTE el texto proporcionado A FORMATO MARKDOWN completo siguiendo estas reglas:
    
    1. Respeta los encabezados existentes (# Título, ## Subtítulo, etc.)
    
    2. Convierte todas estas estructuras a su formato Markdown correcto:
       - Párrafos: Sepáralos con líneas en blanco
       - Listas no ordenadas: Usa guiones o asteriscos (- item o * item)
       - Listas ordenadas: Usa números seguidos de punto (1. item)
       - Énfasis: *cursiva* o **negrita** según corresponda
       - Enlaces: [texto](url) si puedes identificar URLs
       - Citas: > para líneas citadas
       - Código: `código` para código en línea o ```lenguaje para bloques de código
    
    3. Estructura claramente el contenido manteniendo jerarquías lógicas
    
    4. Identifica y corrige problemas como saltos de línea inadecuados o textos mal formateados
    
    5. Asegúrate de que el resultado sea un documento Markdown válido y bien formateado
    
    IMPORTANTE: No inventes contenido ni modifiques el significado del texto original.
    SOLO devuelve el texto convertido a Markdown, sin comentarios ni explicaciones.
    """

    # Instrucciones específicas según el tipo de documento
    specific_instructions = {
        "PDF": """
        Para documentos PDF:
        - Identifica párrafos que puedan estar divididos por saltos de línea y únelos
        - Detecta contenido que podría ser una lista y conviértelo al formato de lista Markdown
        - Identifica encabezados por tipografía (texto más grande, en negrita) y conviértelos al formato de encabezado Markdown apropiado
        """,
        "DOCX": """
        Para documentos DOCX:
        - Convierte cada sección marcada con <TABLA>...</TABLA> en tablas Markdown con este formato:
          ```
          | Encabezado1 | Encabezado2 |
          |------------|-------------|
          | Contenido1 | Contenido2  |
          ```
        - Respeta el énfasis (negrita, cursiva) del texto original
        - Convierte las viñetas en listas Markdown
        """,
        "PPTX": """
        Para presentaciones PPTX:
        - Conserva la estructura de diapositivas marcadas con --- (separador horizontal)
        - Convierte elementos marcados con *, **, etc. en listas anidadas con el formato adecuado
        - Asegúrate de que cada diapositiva tenga su propio encabezado de nivel 2 (##)
        """,
        "XLSX": """
        Para hojas de cálculo XLSX:
        - Convierte todas las secciones marcadas con <TABLA>...</TABLA> en tablas Markdown rigurosas
        - Asegúrate de incluir la línea separadora entre encabezados y datos (|---|---|)
        - Alinea columnas numéricas a la derecha usando :---: o ---: si es necesario
        - Preserva la estructura de cada hoja con su propio encabezado
        """,
    }

    # Combina las instrucciones
    instructions = base_instructions + specific_instructions.get(document_type, "")

    # Sistema y prompt
    system_message = f"""
    Eres un experto en convertir texto plano a formato Markdown de alta calidad.
    Te han proporcionado texto extraído automáticamente de un documento {document_type}.
    Tu tarea PRINCIPAL es CONVERTIR este texto a formato Markdown correctamente estructurado.
    {instructions}
    """

    prompt = f"""
    Aquí está el texto extraído de un documento {document_type}.
    Por favor, CONVIÉRTELO a formato Markdown bien estructurado:

    {text}
    """

    messages = [
        {"role": "system", "content": system_message},
        {"role": "user", "content": prompt},
    ]

    # Llamada al LLM
    response = llm.invoke(messages)
    return response.content
