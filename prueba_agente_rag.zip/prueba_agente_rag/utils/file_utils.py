import os
import shutil
from pathlib import Path
from typing import Optional, Tuple

from config import INPUT_DIR, CONVERTED_DIR


def get_file_extension(file_path: str) -> str:
    """
    Obtiene la extensión de un archivo.

    Args:
        file_path: Ruta al archivo

    Returns:
        Extensión del archivo en minúsculas (sin el punto)
    """
    return os.path.splitext(file_path)[1][1:].lower()


def is_supported_format(file_path: str) -> bool:
    """
    Comprueba si el formato del archivo es compatible.

    Args:
        file_path: Ruta al archivo

    Returns:
        True si el formato es compatible, False en caso contrario
    """
    supported_formats = ["pdf", "docx", "pptx", "xlsx"]
    return get_file_extension(file_path) in supported_formats


def copy_file_to_input_dir(file_path: str) -> Tuple[bool, str]:
    """
    Copia un archivo al directorio de entrada (input).

    Args:
        file_path: Ruta al archivo original

    Returns:
        Tupla (éxito, mensaje/nueva_ruta)
    """
    try:
        file_name = os.path.basename(file_path)
        destination = INPUT_DIR / file_name

        # Copia el archivo
        shutil.copy2(file_path, destination)

        return True, str(destination)
    except Exception as e:
        return False, f"Error al copiar el archivo: {str(e)}"


def get_output_md_path(input_file_path: str) -> Path:
    """
    Genera la ruta para el archivo Markdown convertido.

    Args:
        input_file_path: Ruta al archivo de entrada

    Returns:
        Ruta del archivo Markdown resultante
    """
    file_name = os.path.basename(input_file_path)
    base_name = os.path.splitext(file_name)[0]

    return CONVERTED_DIR / f"{base_name}.md"


def save_markdown(markdown_content: str, output_path: Path) -> Tuple[bool, str]:
    """
    Guarda el contenido Markdown en un archivo.

    Args:
        markdown_content: Contenido en formato Markdown
        output_path: Ruta donde guardar el archivo

    Returns:
        Tupla (éxito, mensaje/ruta_del_archivo)
    """
    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(markdown_content)
        return True, str(output_path)
    except Exception as e:
        return False, f"Error al guardar el archivo Markdown: {str(e)}"


def list_input_files(extension: Optional[str] = None) -> list:
    """
    Lista los archivos en el directorio de entrada, opcionalmente filtrados por extensión.

    Args:
        extension: Opcional, extensión para filtrar (sin el punto)

    Returns:
        Lista de rutas de archivos
    """
    files = []
    for file in os.listdir(INPUT_DIR):
        file_path = INPUT_DIR / file
        if not file_path.is_file():
            continue
        if extension and get_file_extension(str(file_path)) != extension.lower():
            continue
        files.append(file_path)
    return files


def list_converted_files() -> list:
    """
    Lista los archivos Markdown en el directorio de archivos convertidos.

    Returns:
        Lista de rutas de archivos Markdown
    """
    return [
        CONVERTED_DIR / file
        for file in os.listdir(CONVERTED_DIR)
        if (CONVERTED_DIR / file).is_file() and file.endswith(".md")
    ]
