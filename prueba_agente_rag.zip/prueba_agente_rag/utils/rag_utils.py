from typing import List
from pathlib import Path

from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_openai import ChatOpenAI
from langchain.schema import Document

from config import (
    CHUNK_SIZE,
    CHUNK_OVERLAP,
    EMBEDDING_MODEL,
    MODEL_NAME,
    OPENAI_API_KEY,
    TOP_K_RESULTS,
)


def load_markdown_document(markdown_path: Path) -> str:
    """
    Carga un documento Markdown desde una ruta.

    Args:
        markdown_path: Ruta al documento Markdown

    Returns:
        Contenido del documento Markdown
    """

    with open(markdown_path, "r", encoding="utf-8") as f:
        return f.read()


def split_text(text: str) -> List[Document]:
    """
    Divide el texto en chunks para el procesamiento RAG.

    Args:
        text: Texto a dividir

    Returns:
        Lista de documentos fragmentados
    """

    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        length_function=len,
    )

    # Convierte el texto en documentos con metadatos muy básicos
    docs = [Document(page_content=text, metadata={"source": "document"})]

    # Divide en chunks
    return text_splitter.split_documents(docs)


def create_vectorstore(documents: List[Document]) -> FAISS:
    """
    Crea un almacén de vectores a partir de documentos.

    Args:
        documents: Lista de documentos para embeber

    Returns:
        Almacén de vectores FAISS
    """

    embeddings = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY, model=EMBEDDING_MODEL)
    return FAISS.from_documents(documents, embeddings)


def retrieve_context(vectorstore: FAISS, query: str) -> List[Document]:
    """
    Recupera los chunks más relevantes de una consulta.

    Args:
        vectorstore: Almacén de vectores FAISS
        query: Consulta del usuario

    Returns:
        Lista de documentos relevantes
    """

    return vectorstore.similarity_search(query, k=TOP_K_RESULTS)


def format_context(documents: List[Document]) -> str:
    """
    Formatea los documentos recuperados.

    Args:
        documents: Lista de documentos recuperados

    Returns:
        Contexto formateado como texto
    """

    context_parts = []

    for i, doc in enumerate(documents):
        context_parts.append(f"[Documento {i+1}]\n{doc.page_content}\n")

    return "\n".join(context_parts)


def query_llm_with_context(query: str, context: str) -> str:
    """
    Consulta al modelo de lenguaje con el contexto proporcionado.

    Args:
        query: Consulta del usuario
        context: Contexto recuperado

    Returns:
        Respuesta del LLM
    """

    llm = ChatOpenAI(
        openai_api_key=OPENAI_API_KEY, model_name=MODEL_NAME, temperature=0
    )

    system_message = """
    Eres un asistente útil que responde preguntas basándote únicamente en la información proporcionada.
    Si la información no es suficiente para responder, indica que no tienes suficiente contexto.
    No inventes información que no esté en el contexto.
    """

    prompt = f"""
    Contexto:
    {context}
    
    Pregunta:
    {query}
    
    Por favor, responde a la pregunta basándote únicamente en el contexto proporcionado.
    """

    messages = [
        {"role": "system", "content": system_message},
        {"role": "user", "content": prompt},
    ]

    response = llm.invoke(messages)
    return response.content


def process_markdown_query(markdown_path: Path, query: str) -> str:
    """
    Procesa una consulta para un documento Markdown utilizando RAG.

    Args:
        markdown_path: Ruta al documento Markdown
        query: Consulta del usuario

    Returns:
        Respuesta a la consulta
    """

    # Carga el documento MD y lo divide en chunks
    text = load_markdown_document(markdown_path)
    chunks = split_text(text)

    # Crear un vectorstore a partir de chunks
    vectorstore = create_vectorstore(chunks)

    # Recuperar los chunks más relevantes y los formatea
    relevant_docs = retrieve_context(vectorstore, query)
    context = format_context(relevant_docs)

    # Llama al LLM pasando el contexto y la query
    return query_llm_with_context(query, context)
