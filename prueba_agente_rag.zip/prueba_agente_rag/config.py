import os
from pathlib import Path
from dotenv import load_dotenv

# Cargar variables de entorno desde archivo .env
load_dotenv()

# Rutas de la aplicación
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
INPUT_DIR = DATA_DIR / "input"
CONVERTED_DIR = DATA_DIR / "converted"

# Check para asegurar que los directorios existan
INPUT_DIR.mkdir(parents=True, exist_ok=True)
CONVERTED_DIR.mkdir(parents=True, exist_ok=True)

# Configuración del LLM desde variables de entorno
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
MODEL_NAME = os.getenv("MODEL_NAME", "gpt-3.5-turbo")

# Configuración del RAG desde variables de entorno
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "1000"))
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "200"))
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "text-embedding-ada-002")
TOP_K_RESULTS = int(os.getenv("TOP_K_RESULTS", "5"))

# System prompt
AGENT_SYSTEM_MESSAGE = """
Eres un asistente que ayuda a responder preguntas basadas en documentos.
Tienes acceso a 4 herramientas para convertir diferentes formatos de documentos a Markdown:
1. pdf_to_md_tool: Convierte documentos PDF a Markdown
2. docx_to_md_tool: Convierte documentos DOCX a Markdown
3. pptx_to_md_tool: Convierte presentaciones PPTX a Markdown
4. xlsx_to_md_tool: Convierte hojas de cálculo XLSX a Markdown

Tu objetivo es:
1. Identificar el formato del documento
2. Convertirlo a Markdown usando la herramienta adecuada
3. Utilizar el documento convertido para responder preguntas mediante RAG (Retrieval Augmented Generation)

Siempre explica brevemente el proceso que seguiste para obtener la respuesta.
"""