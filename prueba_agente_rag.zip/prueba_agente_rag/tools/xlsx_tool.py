from pathlib import Path
import pandas as pd
import openpyxl
from langchain_core.tools import tool

from utils.file_utils import get_output_md_path, save_markdown
from utils.llm_utils import enhance_markdown_with_llm


@tool
def xlsx_to_md_tool(file_path: str) -> str:
    """
    Convierte una hoja de cálculo XLSX a formato Markdown.

    Args:
        file_path: Ruta al archivo XLSX

    Returns:
        Ruta al archivo Markdown generado o mensaje de error
    """

    try:
        # Comprueba si el archivo existe
        xlsx_path = Path(file_path)
        if not xlsx_path.exists():
            return f"Error: El archivo {file_path} no existe."

        # Abre el libro Excel
        workbook = openpyxl.load_workbook(file_path, data_only=True)

        # Lista de hojas del XLSX
        extracted_text = []

        # Título del documento (nombre del archivo)
        file_name = xlsx_path.stem
        extracted_text.append(f"# {file_name}\n")

        # Añade cada hoja a la lista
        for sheet_name in workbook.sheetnames:
            extracted_text.append(f"## Hoja: {sheet_name}\n")

            # Carga la hoja con pandas para facilitar la extracción
            df = pd.read_excel(file_path, sheet_name=sheet_name)

            # Procesa el DataFrame
            if not df.empty:
                # Limita el número de filas si el DataFrame es muy grande
                if len(df) > 100:
                    extracted_text.append(
                        f"*Nota: Mostrando las primeras 100 filas de {len(df)} totales*\n"
                    )
                    df = df.head(100)

                # Convierte a texto con formato de tabla
                extracted_text.append("<TABLA>")

                # Encabezados
                extracted_text.append(" | ".join(df.columns.astype(str)))

                # Datos
                for _, row in df.iterrows():
                    row_str = " | ".join(row.astype(str))
                    extracted_text.append(row_str)

                extracted_text.append("</TABLA>")
            else:
                extracted_text.append("*Esta hoja está vacía*")

            extracted_text.append("\n")  # Separador entre hojas

        # Información adicional
        extracted_text.append(f"## Información del Archivo\n")
        extracted_text.append(f"- Nombre: {xlsx_path.name}")
        extracted_text.append(f"- Hojas: {', '.join(workbook.sheetnames)}")
        extracted_text.append(f"- Total de hojas: {len(workbook.sheetnames)}")

        # Combina la lista con todas las hojas
        raw_text = "\n".join(extracted_text)

        # Usa el LLM para mejorar el formato Markdown
        markdown_content = enhance_markdown_with_llm(raw_text, "XLSX")

        # Define la ruta de salida y guarda el archivo
        output_path = get_output_md_path(file_path)
        success, result = save_markdown(markdown_content, output_path)

        # Muestra mensaje con el resultado
        if success:
            return f"Hoja de cálculo XLSX convertida exitosamente a Markdown: {result}"
        else:
            return f"Error al guardar el archivo Markdown: {result}"

    except Exception as e:
        return f"Error al convertir el XLSX a Markdown: {str(e)}"
