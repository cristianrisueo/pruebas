from pathlib import Path
from langchain_core.tools import tool
from pptx import Presentation

from utils.file_utils import get_output_md_path, save_markdown
from utils.llm_utils import enhance_markdown_with_llm


@tool
def pptx_to_md_tool(file_path: str) -> str:
    """
    Convierte una presentación PPTX a formato Markdown.

    Args:
        file_path: Ruta al archivo PPTX

    Returns:
        Ruta al archivo Markdown generado o mensaje de error
    """

    try:
        # Comprueba si el archivo existe
        pptx_path = Path(file_path)
        if not pptx_path.exists():
            return f"Error: El archivo {file_path} no existe."

        # Abre la presentación
        prs = Presentation(file_path)

        # Lista de diapositivas del PPTX
        extracted_text = []

        # Título del documento (nombre del archivo)
        file_name = pptx_path.stem
        extracted_text.append(f"# {file_name}\n")

        # Función segura para extraer texto de cualquier forma
        def get_text_safely(shape) -> str:
            """Extrae texto de una forma de manera segura, evitando excepciones."""
            try:
                if hasattr(shape, "text"):
                    return shape.text.strip()
                return ""
            except Exception:
                return ""

        # Función para determinar si una forma es un título
        def is_title_shape(shape) -> bool:
            """Determina si una forma es probablemente un título."""
            try:
                # Método 1: propiedad is_title
                if hasattr(shape, "is_title") and shape.is_title:
                    return True

                # Método 2: placeholder_format.type
                if hasattr(shape, "placeholder_format") and hasattr(
                    shape.placeholder_format, "type"
                ):
                    try:
                        # Tipo 1 es título
                        return shape.placeholder_format.type == 1
                    except:
                        pass

                # Método 3: nombre de placeholder
                if hasattr(shape, "name") and "Title" in shape.name:
                    return True

                return False
            except Exception:
                return False

        # Función para extraer nivel de párrafo de manera segura
        def get_paragraph_level(paragraph) -> int:
            """Extrae el nivel de un párrafo de manera segura."""
            try:
                if hasattr(paragraph, "level"):
                    return paragraph.level
                return 0
            except Exception:
                return 0

        # Añade cada diapositiva a la lista
        for i, slide in enumerate(prs.slides):
            # Título de la diapositiva
            slide_title = f"## Diapositiva {i+1}"

            # Intenta extraer el título real de la diapositiva
            try:
                # Busca una forma que parezca un título
                for shape in slide.shapes:
                    if is_title_shape(shape):
                        title_text = get_text_safely(shape)
                        if title_text:
                            slide_title = f"## Diapositiva {i+1}: {title_text}"
                            break
            except Exception:
                # Si falla, mantén el título genérico
                pass

            extracted_text.append(slide_title)
            extracted_text.append("")  # Línea en blanco

            # Extrae el texto de la diapositiva
            slide_content = []

            # Procesa todas las formas en la diapositiva
            for shape in slide.shapes:
                try:
                    # Obtén el texto de la forma
                    text = get_text_safely(shape)

                    # Si no hay texto o es el título (que ya procesamos), continúa
                    if not text or is_title_shape(shape):
                        continue

                    # Intenta procesar como texto con formato (párrafos)
                    if hasattr(shape, "text_frame"):
                        try:
                            # Procesa cada párrafo
                            if hasattr(shape.text_frame, "paragraphs"):
                                for paragraph in shape.text_frame.paragraphs:
                                    try:
                                        line = paragraph.text.strip()
                                        if not line:
                                            continue

                                        # Determina el nivel de indentación
                                        level = get_paragraph_level(paragraph)

                                        # Formatea según el nivel
                                        if level > 0:
                                            slide_content.append(
                                                "*" * level + " " + line
                                            )
                                        else:
                                            slide_content.append(line)
                                    except Exception:
                                        # Si falla al procesar un párrafo específico, agrégalo sin formato
                                        if paragraph.text.strip():
                                            slide_content.append(paragraph.text.strip())
                        except Exception:
                            # Si falla al procesar texto_frame, usa el texto plano
                            slide_content.append(text)
                    else:
                        # Agrega como texto simple
                        slide_content.append(text)
                except Exception:
                    # Si falla completamente al procesar una forma, continúa con la siguiente
                    continue

            # Añade el contenido de la diapositiva
            extracted_text.extend(slide_content)

            # Añade una línea en blanco si no hay contenido
            if not slide_content:
                extracted_text.append(
                    "*No se encontró contenido extraíble en esta diapositiva*"
                )

            # Separador entre diapositivas
            extracted_text.append("\n---\n")

        # Combina la lista con todas las diapositivas
        raw_text = "\n".join(extracted_text)

        # Usa el LLM para mejorar el formato Markdown
        markdown_content = enhance_markdown_with_llm(raw_text, "PPTX")

        # Define la ruta de salida y guarda el archivo
        output_path = get_output_md_path(file_path)
        success, result = save_markdown(markdown_content, output_path)

        # Muestra mensaje con el resultado
        if success:
            return f"Presentación PPTX convertida exitosamente a Markdown: {result}"
        else:
            return f"Error al guardar el archivo Markdown: {result}"

    except Exception as e:
        # Si todo falla, extrae el texto de forma muy básica
        try:
            # Intenta una extracción de emergencia
            emergency_text = ["# " + pptx_path.stem + "\n"]

            # Extrae solo texto plano de las diapositivas
            for i, slide in enumerate(prs.slides):
                emergency_text.append(f"## Diapositiva {i+1}\n")
                for shape in slide.shapes:
                    try:
                        if hasattr(shape, "text") and shape.text.strip():
                            emergency_text.append(shape.text.strip())
                    except:
                        pass
                emergency_text.append("\n---\n")

            # Guarda el resultado de emergencia
            emergency_content = "\n".join(emergency_text)
            output_path = get_output_md_path(file_path)
            enhance_markdown_with_llm(emergency_content, "PPTX")
            success, result = save_markdown(emergency_content, output_path)

            if success:
                return (
                    f"Presentación PPTX convertida (modo básico) a Markdown: {result}"
                )
            else:
                return f"Error al convertir el PPTX a Markdown: {str(e)}"

        except Exception as final_e:
            return f"Error al convertir el PPTX a Markdown: {str(e)}. Error adicional: {str(final_e)}"
