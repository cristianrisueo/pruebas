from pathlib import Path
from langchain_core.tools import tool
import docx

from utils.file_utils import get_output_md_path, save_markdown
from utils.llm_utils import enhance_markdown_with_llm


@tool
def docx_to_md_tool(file_path: str) -> str:
    """
    Convierte un documento DOCX a formato Markdown.

    Args:
        file_path: Ruta al archivo DOCX

    Returns:
        Ruta al archivo Markdown generado o mensaje de error
    """

    try:
        # Comprueba si el archivo existe
        docx_path = Path(file_path)
        if not docx_path.exists():
            return f"Error: El archivo {file_path} no existe."

        # Abreel documento Word
        doc = docx.Document(file_path)

        # Lista de páginas del DOCX
        extracted_text = []

        # Título del documento (nombre del archivo)
        file_name = docx_path.stem
        extracted_text.append(f"# {file_name}\n")

        # Añade cada página a la lista
        for para in doc.paragraphs:
            if para.text.strip():
                # Detecta los encabezados y los párrafos
                if para.style.name.startswith("Heading 1"):
                    extracted_text.append(f"## {para.text}")
                elif para.style.name.startswith("Heading 2"):
                    extracted_text.append(f"### {para.text}")
                elif para.style.name.startswith("Heading 3"):
                    extracted_text.append(f"#### {para.text}")
                else:
                    extracted_text.append(para.text)

                extracted_text.append("")  # Línea en blanco

        # Añade las tablas a la lista
        for table in doc.tables:
            extracted_text.append("\n<TABLA>\n")

            for row in table.rows:
                row_text = []
                for cell in row.cells:
                    row_text.append(cell.text.strip() or " ")

                extracted_text.append(" | ".join(row_text))

            extracted_text.append("\n</TABLA>\n")

        # Combina la lista con todas las páginas y tablas
        raw_text = "\n".join(extracted_text)

        # Usa el LLM para mejorar el formato Markdown
        markdown_content = enhance_markdown_with_llm(raw_text, "DOCX")

        # Define la ruta de salida y guarda el archivo
        output_path = get_output_md_path(file_path)
        success, result = save_markdown(markdown_content, output_path)

        # Muestra mensaje con el resultado
        if success:
            return f"Documento DOCX convertido exitosamente a Markdown: {result}"
        else:
            return f"Error al guardar el archivo Markdown: {result}"

    except Exception as e:
        return f"Error al convertir el DOCX a Markdown: {str(e)}"
