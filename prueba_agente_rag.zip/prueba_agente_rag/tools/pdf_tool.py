from pathlib import Path
from langchain_core.tools import tool
from pypdf import PdfReader

from utils.file_utils import get_output_md_path, save_markdown
from utils.llm_utils import enhance_markdown_with_llm


@tool
def pdf_to_md_tool(file_path: str) -> str:
    """
    Convierte un documento PDF a formato Markdown.

    Args:
        file_path: Ruta al archivo PDF

    Returns:
        Ruta al archivo Markdown generado o mensaje de error
    """

    try:
        # Comprueba si el archivo existe
        pdf_path = Path(file_path)
        if not pdf_path.exists():
            return f"Error: El archivo {file_path} no existe."

        # Abre y lee el PDF
        pdf_reader = PdfReader(file_path)

        # Lista de páginas del PDF
        extracted_text = []

        # Título del documento (nombre del archivo)
        file_name = pdf_path.stem
        extracted_text.append(f"# {file_name}\n")

        # Añade cada página a la lista
        for i, page in enumerate(pdf_reader.pages):
            text = page.extract_text()

            if text.strip():
                extracted_text.append(f"## Página {i+1}\n")
                extracted_text.append(text)
                extracted_text.append("\n")

        # Combina la lista con todas las páginas
        raw_text = "\n".join(extracted_text)

        # Usa el LLM para mejorar el formato Markdown
        markdown_content = enhance_markdown_with_llm(raw_text, "PDF")

        # Define la ruta de salida y guarda el archivo
        output_path = get_output_md_path(file_path)
        success, result = save_markdown(markdown_content, output_path)

        # Muestra mensaje con el resultado
        if success:
            return f"Documento PDF convertido exitosamente a Markdown: {result}"
        else:
            return f"Error al guardar el archivo Markdown: {result}"

    except Exception as e:
        return f"Error al convertir el PDF a Markdown: {str(e)}"
