# Este archivo convierte el directorio en un paquete Python

from tools.pdf_tool import pdf_to_md_tool
from tools.docx_tool import docx_to_md_tool
from tools.pptx_tool import pptx_to_md_tool
from tools.xlsx_tool import xlsx_to_md_tool

# Lista de todas las herramientas disponibles
available_tools = [pdf_to_md_tool, docx_to_md_tool, pptx_to_md_tool, xlsx_to_md_tool]
