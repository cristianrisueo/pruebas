# RAG Multiformat

Sistema de Recuperación Aumentada por Generación (RAG) para múltiples formatos de documentos.

## Descripción

Este proyecto implementa un sistema RAG que permite realizar consultas sobre documentos en diferentes formatos (PDF, DOCX, PPTX y XLSX). El sistema:

1. Convierte automáticamente el documento al formato Markdown
2. Divide el documento en fragmentos para su procesamiento
3. Crea embeddings vectoriales para búsqueda semántica
4. Recupera los fragmentos más relevantes para responder a la consulta
5. Genera una respuesta basada en el contexto recuperado

## Características

- Soporte para múltiples formatos de documentos:
  - PDF: Documentos y artículos
  - DOCX: Documentos de Word
  - PPTX: Presentaciones de PowerPoint
  - XLSX: Hojas de cálculo de Excel
- Conversión automática a Markdown para su procesamiento
- Interfaz de línea de comandos simple
- Recuperación de contexto relevante basada en la consulta
- Respuestas generadas utilizando modelos de lenguaje de OpenAI

## Requisitos

- Python 3.8 o superior
- API key de OpenAI
- Dependencias del proyecto (ver `requirements.txt`)

## Instalación

1. Clona este repositorio:
   ```bash
   git clone https://github.com/usuario/rag-multiformat.git
   cd rag-multiformat
   ```

2. Instala las dependencias:
   ```bash
   pip install -r requirements.txt
   ```

3. Crea un archivo `.env` con tu API key de OpenAI:
   ```
   OPENAI_API_KEY=tu_api_key_aquí
   ```

## Estructura de directorios

```
rag-multiformat/
├── data/
│   ├── input/          # Directorio para documentos de entrada
│   └── converted/      # Directorio para documentos convertidos a MD
├── tools/
│   ├── __init__.py
│   ├── pdf_tool.py     # Tool para convertir PDF a MD
│   ├── docx_tool.py    # Tool para convertir DOCX a MD
│   ├── pptx_tool.py    # Tool para convertir PPTX a MD
│   └── xlsx_tool.py    # Tool para convertir XLSX a MD
├── utils/
│   ├── __init__.py
│   ├── file_utils.py   # Utilidades para manejo de archivos
│   ├── llm_utils.py    # Utilidades para interacción con LLM
│   └── rag_utils.py    # Utilidades para procesamiento RAG
├── agent.py            # Agente principal que procesa documentos y consultas
├── config.py           # Configuración del proyecto
├── main.py             # Punto de entrada del programa
└── requirements.txt    # Dependencias del proyecto
```

## Uso

1. Coloca el documento que quieres consultar en la carpeta `data/input/`

2. Ejecuta el programa con el nombre del archivo y tu consulta:
   ```bash
   python main.py --file documento.pdf --query "¿Cuál es la información principal en este documento?"
   ```

3. El sistema procesará el documento y responderá a tu consulta basándose en su contenido.

## Ejemplos

**Consulta sobre un PDF:**
```bash
python main.py --file informe_anual.pdf --query "¿Cuáles fueron los ingresos del último trimestre?"
```

**Consulta sobre una presentación:**
```bash
python main.py --file estrategia_2023.pptx --query "¿Cuáles son los objetivos principales para el próximo año?"
```

**Consulta sobre una hoja de cálculo:**
```bash
python main.py --file ventas_q3.xlsx --query "¿Qué producto generó más ingresos?"
```

## Notas técnicas

- El sistema siempre genera un nuevo archivo Markdown al procesar un documento, eliminando cualquier versión anterior.
- Los archivos convertidos se guardan en `data/converted/` con el mismo nombre pero extensión `.md`.
- El modelo utilizado para embeddings es `text-embedding-ada-002` de OpenAI.
- El tamaño de los fragmentos y el solapamiento pueden ajustarse en `config.py`.

## Limitaciones

- El sistema requiere una API key válida de OpenAI.
- La calidad de la extracción puede variar según la complejidad y formato del documento.
- Documentos muy grandes pueden consumir un tiempo considerable en su procesamiento.
- Las tablas complejas en XLSX pueden no convertirse perfectamente.

## Licencia

[MIT](LICENSE)
