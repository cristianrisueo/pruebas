from typing import Dict, Any
import os

from tools.pdf_tool import pdf_to_md_tool
from tools.docx_tool import docx_to_md_tool
from tools.pptx_tool import pptx_to_md_tool
from tools.xlsx_tool import xlsx_to_md_tool
from utils.file_utils import get_file_extension, get_output_md_path
from utils.rag_utils import process_markdown_query


def process_document_and_query(file_path: str, query: str) -> Dict[str, Any]:
    """
    Procesa un documento y una consulta de usuario.

    Args:
        file_path: Ruta al archivo a procesar
        query: Consulta del usuario

    Returns:
        Diccionario con resultados del procesamiento
    """

    # Obtiene la ruta donde se guardará el archivo MD
    output_md_path = get_output_md_path(file_path)
    conversion_performed = False

    # Si ya existe algún fichero en esa ruta lo elimina antes de realizar la conversión
    if output_md_path.exists():
        try:
            os.remove(output_md_path)
            print(f"Archivo Markdown previo eliminado: {output_md_path}")
        except Exception as e:
            return {
                "success": False,
                "error": f"Error al eliminar archivo Markdown existente: {str(e)}",
                "conversion_performed": False,
            }

    # Obtiene la extensión del archivo a convertir
    extension = get_file_extension(file_path)

    # Convierte el documento a MD según su extensión
    conversion_result = ""
    if extension == "pdf":
        conversion_result = pdf_to_md_tool.invoke(file_path)
    elif extension == "docx":
        conversion_result = docx_to_md_tool.invoke(file_path)
    elif extension == "pptx":
        conversion_result = pptx_to_md_tool.invoke(file_path)
    elif extension == "xlsx":
        conversion_result = xlsx_to_md_tool.invoke(file_path)
    else:
        return {
            "success": False,
            "error": f"Formato no soportado: {extension}",
            "conversion_performed": False,
        }

    # Comprueba si la conversión fue exitosa
    md_file_exists = output_md_path.exists()
    conversion_performed = True

    # Si no se generó el archivo MD, devuelve error
    if not md_file_exists:
        return {
            "success": False,
            "error": f"Error en la conversión: {conversion_result}",
            "md_file_exists": False,
            "md_file_path": None,
            "conversion_performed": conversion_performed,
        }

    # Realiza la consulta RAG sobre el documento
    try:
        response = process_markdown_query(output_md_path, query)

        # Devuelve la respuesta y metadatos
        return {
            "success": True,
            "md_file_path": str(output_md_path),
            "md_file_exists": True,
            "response": response,
            "conversion_result": conversion_result,
            "conversion_performed": conversion_performed,
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "md_file_exists": True,
            "md_file_path": str(output_md_path),
            "conversion_result": conversion_result,
            "conversion_performed": conversion_performed,
        }
