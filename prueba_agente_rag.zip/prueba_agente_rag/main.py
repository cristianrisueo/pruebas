import argparse
import os
from pathlib import Path

from utils.file_utils import (
    is_supported_format,
    get_output_md_path,
    list_input_files,
)
from agent import process_document_and_query
from config import OPENAI_API_KEY, INPUT_DIR


def check_environment():
    """Comprueba que exista la variable de entorno con la API key."""

    if not OPENAI_API_KEY:
        print("ERROR: La variable de entorno OPENAI_API_KEY no está configurada.")
        return False

    return True


def main():
    """Función principal del programa."""

    # Comprueba la API KEY del .env
    if not check_environment():
        return

    # Argumentos por consola para probar el funcionamiento
    parser = argparse.ArgumentParser(
        description="RAG con múltiples formatos de documentos"
    )

    # Solo pide el nombre del archivo (no la ruta completa)
    parser.add_argument(
        "--file", "-f", type=str, help="Nombre del archivo a procesar", required=True
    )

    # Consulta para hacer RAG
    parser.add_argument(
        "--query",
        "-q",
        type=str,
        help="Consulta a realizar sobre el documento",
        required=True,
    )

    args = parser.parse_args()

    # Construir la ruta completa al archivo en la carpeta input
    file_path = INPUT_DIR / args.file

    # Comprueba que el archivo exista
    if not file_path.exists():
        print(f"ERROR: El archivo {args.file} no existe en la carpeta input.")
        print(f"Por favor, asegúrate de que el archivo esté en: {INPUT_DIR}")

        # Muestra los archivos disponibles en la carpeta input
        available_files = list_input_files()
        if available_files:
            print("\nArchivos disponibles en la carpeta input:")
            for f in available_files:
                print(f"- {f.name}")
        return

    # Comprueba que el formato sea compatible
    if not is_supported_format(str(file_path)):
        print(f"ERROR: El formato del archivo {args.file} no es compatible.")
        print("Formatos soportados: PDF, DOCX, PPTX, XLSX")
        return

    # Procesa el documento y la consulta
    print(f"Procesando archivo: {file_path}")
    print(f"Consulta: {args.query}")

    # Comprueba si ya existe un archivo Markdown en la carpeta converted con ese nombre
    output_md_path = get_output_md_path(str(file_path))
    if output_md_path.exists():
        print(f"Se eliminará y regenerará el archivo Markdown: {output_md_path}")
    else:
        print("Convirtiendo documento...")

    # Procesa el documento y realiza la consulta
    result = process_document_and_query(str(file_path), args.query)

    if result["success"]:
        print(f"Documento convertido exitosamente a: {result['md_file_path']}")

        print("\nRespuesta a la consulta:")
        print("-" * 50)
        print(result["response"])
        print("-" * 50)
    else:
        print(f"Error al procesar el documento: {result['error']}")


if __name__ == "__main__":
    main()
