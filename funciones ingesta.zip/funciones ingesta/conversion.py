import os
from pptx import Presentation
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from PIL import Image
import pandas as pd
import tempfile


def pptx_to_pdf(pptx_path, pdf_output_path):
    """
    Convierte un archivo PowerPoint (.pptx) a PDF.

    Args:
        pptx_path (str): Ruta del archivo PPTX de entrada
        pdf_output_path (str): Ruta donde se guardará el PDF resultante

    Returns:
        str: Ruta del archivo PDF generado
    """
    # Cargar la presentación
    presentation = Presentation(pptx_path)

    # Crear el PDF
    c = canvas.Canvas(pdf_output_path, pagesize=letter)
    width, height = letter

    # Procesar cada diapositiva
    for slide_num, slide in enumerate(presentation.slides):
        if slide_num > 0:
            c.showPage()  # Nueva página para cada diapositiva (excepto la primera)

        # Título de la diapositiva
        y_position = height - 50
        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, y_position, f"Diapositiva {slide_num + 1}")

        # Extraer texto de la diapositiva
        y_position -= 40
        c.setFont("Helvetica", 12)

        for shape in slide.shapes:
            if hasattr(shape, "text"):
                # Dividir texto largo en líneas
                text = shape.text.strip()
                if text:
                    lines = text.split("\n")
                    for line in lines:
                        # Controlar que no nos salgamos de la página
                        if y_position < 50:
                            c.showPage()
                            y_position = height - 50

                        # Escribir la línea
                        c.drawString(50, y_position, line[:80])  # Limitar longitud
                        y_position -= 20

    # Guardar el PDF
    c.save()
    return pdf_output_path


def xlsx_to_html(xlsx_path, html_output_path):
    """
    Convierte un archivo Excel (.xlsx) a HTML con formato de tabla.

    Args:
        xlsx_path (str): Ruta del archivo XLSX de entrada
        html_output_path (str): Ruta donde se guardará el HTML resultante

    Returns:
        str: Ruta del archivo HTML generado
    """
    # Leer el archivo Excel
    excel_file = pd.ExcelFile(xlsx_path)

    # Inicio del HTML con estilos CSS
    html_content = """
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Excel a HTML</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 20px;
                background-color: #f5f5f5;
            }
            h2 {
                color: #333;
                border-bottom: 2px solid #4CAF50;
                padding-bottom: 10px;
            }
            table {
                border-collapse: collapse;
                width: 100%;
                margin-bottom: 30px;
                background-color: white;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            th {
                background-color: #4CAF50;
                color: white;
                padding: 12px;
                text-align: left;
                font-weight: bold;
            }
            td {
                padding: 10px;
                border-bottom: 1px solid #ddd;
            }
            tr:hover {
                background-color: #f5f5f5;
            }
        </style>
    </head>
    <body>
    """

    # Procesar cada hoja del Excel
    for sheet_name in excel_file.sheet_names:
        # Leer la hoja actual
        df = pd.read_excel(xlsx_path, sheet_name=sheet_name)

        # Agregar título de la hoja
        html_content += f"<h2>Hoja: {sheet_name}</h2>\n"

        # Convertir DataFrame a tabla HTML
        # to_html() genera la tabla, escape=False permite HTML en celdas
        html_table = df.to_html(
            index=False, escape=False, table_id=f"tabla_{sheet_name}"
        )

        html_content += html_table + "\n<br>\n"

    # Cerrar el HTML
    html_content += """
    </body>
    </html>
    """

    # Guardar el archivo HTML
    with open(html_output_path, "w", encoding="utf-8") as f:
        f.write(html_content)

    return html_output_path


# Ejemplo de uso (descomenta para probar)
if __name__ == "__main__":
    # Rutas relativas al directorio del script
    pptx_file = "inputs/pptx/test.pptx"
    pdf_output = "outputs/pdf/presentacion.pdf"

    xlsx_file = "inputs/xlsx/test.xls"  # Nota: tu archivo es .xls, no .xlsx
    html_output = "outputs/html/datos.html"

    # Ejecutar conversiones
    try:
        result_pdf = pptx_to_pdf(pptx_file, pdf_output)
        print(f"✅ PDF creado en: {result_pdf}")
    except Exception as e:
        print(f"❌ Error al convertir PPTX: {e}")

    try:
        result_html = xlsx_to_html(xlsx_file, html_output)
        print(f"✅ HTML creado en: {result_html}")
    except Exception as e:
        print(f"❌ Error al convertir XLSX: {e}")
