# main.py es el punto de entrada de la aplicación FastAPI
import logging
import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.templating import Jinja2Templates
from app.config.global_config import CORS_ORIGINS, APP_HOST, APP_PORT, DEBUG
from app.api.chat_endpoint import router

# Se configura el logger
logger = logging.getLogger(__name__)

# Crea la aplicación FastAPI
app = FastAPI(
    title="Voz-a-ChatGPT API",
    description="API para transcribir voz a texto y obtener respuestas de ChatGPT",
    version="0.1.0",
)

# Configura CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configura las plantillas Jinja2
templates = Jinja2Templates(directory="templates")

# Carga las rutas de WebSocket
app.include_router(router)


# Endpoint principal. Carga la interfaz web
@app.get("/")
async def homepage(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# Inicia la aplicación
if __name__ == "__main__":
    logger.info(f"Iniciando aplicación en {APP_HOST}:{APP_PORT}")
    uvicorn.run(
        "main:app",
        host=APP_HOST,
        port=APP_PORT,
        reload=DEBUG,
    )
