# Voicebot V3: Asistente Conversacional por Voz (diseño caso uso)

Versión avanzada del proyecto Voicebot, que permite mantener una conversación natural con ChatGPT mediante comandos de voz, sin pulsar botones, utilizando detección automática de voz (VAD), transcripción y síntesis de voz con modelos de OpenAI.

---

## 🧠 Funcionalidad General

1. El usuario **comienza a hablar sin pulsar ningún botón**.
2. El navegador detecta automáticamente que está hablando (VAD).
3. El audio se transcribe en el backend y se valida.
4. Si es válido:
   - Se consulta al modelo LLM (`gpt-4o`).
   - Se sintetiza la respuesta con TTS (`tts-1`).
   - Se devuelve también la transcripción del audio generado.
5. Si es inválido:
   - Se reproduce un mensaje estándar: "realiza de nuevo tu consulta".
   - También se muestra la transcripción correspondiente.
6. El frontend:
   - Muestra el texto del usuario y del modelo.
   - Muestra la transcripción junto al botón de reproducción de audio.
   - Reproduce la respuesta del modelo en voz alta.
   - Reactiva automáticamente el micrófono tras la respuesta.

---

## 🧱 Arquitectura del Proyecto

```
voicebot_v3/
├── app/
│   ├── api/
│   │   └── chat_endpoint.py      # WebSocket principal
│   ├── config/
│   │   ├── global_config.py      # Configuraciones generales
│   │   └── websocket_config.py   # Gestión de conexiones
│   └── tools/
│       ├── chatgpt.py            # Servicio de interacción con ChatGPT
│       ├── stt.py                # Transcripción con Whisper o GPT-4o
│       └── tts.py                # Generación de voz con TTS
├── templates/
│   └── index.html                # Frontend HTML+JS
├── static/                       # Archivos estáticos (si es necesario)
├── .env                          # Variables de entorno
├── main.py                       # Punto de entrada FastAPI
├── requirements.txt              # Dependencias del proyecto
└── README.md                     # Este archivo
```

---

## ⚙️ Componentes Detallados

### Backend (FastAPI)

- **WebSocket** (`chat_endpoint.py`):
  - Maneja flujo: audio → transcripción → LLM → audio → respuesta.
  - Controla validación de contenido.
  - Devuelve también la transcripción del audio junto con el audio codificado en base64.
- **STT (`stt.py`)**:
  - Permite cambiar entre `whisper-1`, `gpt-4o-transcribe` o `gpt-4o-mini-transcribe`.
- **TTS (`tts.py`)**:
  - Utiliza `tts-1` o `tts-1-hd` con voces configurables.
- **Moderación**:
  - Si el texto incluye palabras prohibidas, devuelve una respuesta genérica por voz y transcripción correspondiente.

---

## 💻 Frontend

- **Captura de audio automática** mediante VAD (Voice Activity Detection).
- **Visualización**:
  - Mensajes del usuario y asistente como burbujas de texto.
  - Spinners mientras se espera la respuesta.
  - Transcripción visible junto al botón de reproducción del audio generado.
- **Audio**:
  - Reproducción de la respuesta del asistente en voz alta.
  - Micrófono bloqueado durante reproducción.
  - Reactivación automática tras cada respuesta.

---

## 🔁 Flujo de Proceso

```
[ Usuario comienza a hablar ]
        ↓
[ VAD detecta voz y activa grabación ]
        ↓
[ Audio enviado por WebSocket ]
        ↓
[ Transcripción con Whisper o GPT-4o ]
        ↓
[ ChatGPT genera respuesta ]
        ↓
[ TTS convierte respuesta a audio ]
        ↓
[ Texto + transcripción + audio enviados al navegador ]
        ↓
[ Se muestra texto + transcripción + se reproduce voz ]
        ↓
[ Micrófono se reactiva ]
```

---

## 🧪 Requisitos y ejecución

### Instalar dependencias

```bash
pip install -r requirements.txt
```

### Archivo `.env` requerido

Debe contener:

```
OPENAI_API_KEY=sk-...
```

### Arranque del servidor

```bash
uvicorn main:app --reload
```

Accede en navegador a:

```
http://localhost:8000
```

---

## 📌 Estado actual

✅ Conversación por voz sin botones  
✅ UX con spinners de carga  
✅ Validación automática de seguridad  
✅ Audio del asistente y transcripciones visibles  
✅ Micrófono bloqueado durante reproducción  
✅ Transcripción visible junto al audio del asistente (nuevo)

---

## ✨ Autor

Desarrollado por Cristian Risueno Celedonio
