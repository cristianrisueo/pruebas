# chat_endpoint.py contiene el endpoint WebSocket para recibir audio y enviar mensajes a ChatGPT

import json
import logging
import base64
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from app.config.websocket_config import manager
from app.tools.stt import transcribe_audio
from app.tools.chatgpt import ChatGPTService
from app.tools.tts import generate_speech

# Se configura el logger, crea el router y el servicio de ChatGPT
logger = logging.getLogger(__name__)
router = APIRouter()
chatgpt_service = ChatGPTService()


@router.websocket("/ws")
async def chat_endpoint(websocket: WebSocket):
    """
    Endpoint de conexión WebSocket para recibir audio y el comando reset_conversation

    Args:
        websocket (WebSocket): Conexión WebSocket del cliente.

    Returns:
        None
    """

    # Se acepta la conexión WebSocket y se añade a la lista de conexiones activas
    await manager.connect(websocket)

    try:
        while True:
            # Se reciben los datos del cliente
            data = await websocket.receive()

            # Si se reciben bytes de audio
            if "bytes" in data:
                # Se procesan los bytes de audio
                audio_data = data["bytes"]
                logger.info(f"Recibidos {len(audio_data)} bytes de audio")

                # Se envía un mensaje de estado al cliente
                await manager.send_json(
                    {"status": "processing", "message": "Transcribiendo audio..."},
                    websocket,
                )

                # Se transcribe el audio a texto
                transcript_result = await transcribe_audio(audio_data)

                # Se envía el resultado de la transcripción al cliente
                await manager.send_json(
                    {"status": "transcribed", "transcription": transcript_result},
                    websocket,
                )

                # Si la transcripción fue exitosa, se procesa con ChatGPT
                if transcript_result["success"] and transcript_result["text"]:
                    # Se envía un mensaje de estado al cliente
                    await manager.send_json(
                        {
                            "status": "processing",
                            "message": "Procesando con ChatGPT...",
                        },
                        websocket,
                    )

                    # Se obtiene el ID de conversación para esta conexión
                    conversation_id = manager.get_conversation_id(websocket)

                    # Se envía el texto transcrito a ChatGPT
                    chatgpt_result = await chatgpt_service.send_message(
                        transcript_result["text"], conversation_id
                    )

                    # Generar audio
                    audio_bytes = generate_speech(chatgpt_result["message"])
                    audio_base64 = base64.b64encode(audio_bytes).decode("utf-8")

                    # Enviar al cliente
                    await websocket.send_json(
                        {
                            "type": "audio",
                            "format": "audio/mpeg",
                            "audio_base64": audio_base64,
                            "transcription": chatgpt_result["message"],
                        }
                    )

                    logger.info("Procesamiento completo: Transcripción + ChatGPT")

            # Si se recibe un mensaje de texto (para el comando reset_conversation)
            elif "text" in data:
                try:
                    # Se intenta parsear como JSON
                    json_data = json.loads(data["text"])

                    # Si es el comando para reiniciar la conversación reinicia la conversación
                    if json_data.get("command") == "reset_conversation":
                        await manager.reset_conversation(websocket, chatgpt_service)
                        await manager.send_json(
                            {"status": "info", "message": "Conversación reiniciada"},
                            websocket,
                        )

                        logger.info("Conversación reiniciada por comando del cliente")

                # Controla la excepción si el mensaje no es JSON válido
                except json.JSONDecodeError:
                    logger.warning(
                        f"Mensaje de texto recibido no es JSON válido: {data['text']}"
                    )

    # Si se cierra la conexión, se elimina de la lista de conexiones activas
    except WebSocketDisconnect:
        manager.disconnect(websocket)
