# chatgpt.py contiene la lógica para interactuar con la API de OpenAI ChatGPT

import logging
import openai
from typing import List, Dict, Any, Optional
from app.config.global_config import (
    OPENAI_API_KEY,
    OPENAI_MODEL,
    MAX_RESPONSE_TOKENS,
    TEMPERATURE,
)

# Se configura el logging
logger = logging.getLogger(__name__)


class ChatGPTService:
    """
    Servicio para manejar las interacciones con la API de ChatGPT.
    Contiene 4 métodos:
    - __init__: Inicializa el servicio con un cliente OpenAI y un diccionario de conversaciones.
    - _get_conversation: Obtiene o crea una conversación por su ID.
    - send_message: Envía un mensaje a la API de ChatGPT y obtiene una respuesta.
    - clear_conversation: Limpia el historial de una conversación.
    """

    def __init__(self):
        """
        Inicializa el servicio con un cliente OpenAI y un diccionario de conversaciones
        """

        self.client = openai.OpenAI(api_key=OPENAI_API_KEY)
        self.conversations: Dict[str, List[Dict[str, str]]] = {}

    def _get_conversation(self, conversation_id: str) -> List[Dict[str, str]]:
        """
        Obtiene o crea una conversación por su ID.

        Args:
            conversation_id: Identificador único de la conversación

        Returns:
            Lista de mensajes de la conversación
        """

        # Si la conversación no existe, se crea con un mensaje del sistema
        if conversation_id not in self.conversations:
            self.conversations[conversation_id] = [
                {
                    "role": "system",
                    "content": "Eres un asistente útil y amigable. Responde de manera concisa.",
                }
            ]

        return self.conversations[conversation_id]

    async def send_message(
        self,
        message: str,
        conversation_id: str,
        max_tokens: Optional[int] = MAX_RESPONSE_TOKENS,
    ) -> Dict[str, Any]:
        """
        Envía un mensaje a la API de ChatGPT y obtiene una respuesta.

        Args:
            message: Texto del mensaje a enviar
            conversation_id: Identificador de la conversación
            max_tokens: Número máximo de tokens para la respuesta

        Returns:
            Diccionario con la respuesta del modelo y metadatos
        """

        try:
            # Se obtiene la conversación actual
            conversation = self._get_conversation(conversation_id)

            # Se añade el mensaje del usuario a la conversación
            conversation.append({"role": "user", "content": message})

            logger.info(f"Enviando mensaje a ChatGPT: {message[:50]}...")

            # Se realiza la llamada a la API de OpenAI
            response = self.client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=conversation,
                max_tokens=max_tokens,
                temperature=TEMPERATURE,
            )

            # Se extrae la respuesta del asistente
            assistant_message = response.choices[0].message.content

            # Se añade la respuesta a la conversación
            conversation.append({"role": "assistant", "content": assistant_message})

            logger.info(f"Respuesta recibida: {assistant_message[:50]}...")

            # Se devuelve el resultado
            return {
                "success": True,
                "message": assistant_message,
                "usage": {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                },
            }

        except Exception as e:
            logger.error(f"Error al comunicarse con ChatGPT: {str(e)}")
            return {"success": False, "error": str(e)}

    def clear_conversation(self, conversation_id: str) -> Dict[str, Any]:
        """
        Limpia el historial de una conversación.

        Args:
            conversation_id: Identificador de la conversación a limpiar

        Returns:
            Diccionario indicando el resultado de la operación
        """

        try:
            if conversation_id in self.conversations:
                # Se elimina la conversación existente
                del self.conversations[conversation_id]

                # Se crea una nueva conversación vacía
                self._get_conversation(conversation_id)
                logger.info(f"Conversación {conversation_id} reiniciada")

                return {"success": True, "message": "Conversación reiniciada"}

            # Se maneja el caso en que la conversación no existe
            else:
                logger.warning(
                    f"Intento de limpiar una conversación inexistente: {conversation_id}"
                )
                return {"success": False, "error": "Conversación no encontrada"}

        # Se maneja cualquier excepción durante la limpieza de la conversación
        except Exception as e:
            logger.error(f"Error al limpiar conversación: {str(e)}")
            return {"success": False, "error": str(e)}
