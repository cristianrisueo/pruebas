# stt.py contiene la lógica convertir texto a audio usando la API de OpenAI

from openai import OpenAI
import logging
from app.config.global_config import OPENAI_API_KEY

# Configura el logging
logger = logging.getLogger(__name__)


def generate_speech(text: str) -> bytes:
    """
    Convierte texto a audio usando la API de OpenAI.

    Args:
        text (str): El texto a convertir a audio.

    Returns:
        bytes: El audio generado en formato bytes.

    Raises:
        Exception: Si ocurre un error al llamar a la API de OpenAI.
    """

    try:
        # Imprime a log y realiza la conversión a audio del texto recibido
        logger.info(f"Conviertiendo texto a audio: {text}")
        client = OpenAI(api_key=OPENAI_API_KEY)

        response = client.audio.speech.create(
            model="tts-1",
            voice="alloy",
            input=text,
        )

        # Devuelve la respuesta
        return response.content
    except Exception as e:
        logger.error(f"Error durante la transcripción: {str(e)}")
