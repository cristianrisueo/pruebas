# stt.py contiene la lógica para transcribir audio a texto usando la API de OpenAI Whisper

import io
import logging
from typing import Optional
import openai
from app.config.global_config import OPENAI_API_KEY

# Configura el logging
logger = logging.getLogger(__name__)


async def transcribe_audio(audio_data: bytes, language: Optional[str] = "es") -> dict:
    """
    Transcribe audio a texto usando OpenAI Whisper API.

    Args:
        audio_data: Bytes de audio
        language: Código de idioma para la transcripción (por defecto "es" para español)

    Returns:
        dict: Resultado de la transcripción de OpenAI, incluyendo el texto y el idioma.

    Raises:
        Exception: Si ocurre un error al llamar a la API de OpenAI.
    """

    try:
        # Crea un archivo temporal a partir de los bytes de audio con extensión .webm
        audio_file = io.BytesIO(audio_data)
        audio_file.name = "audio.webm"

        # Envia el archivo de audio a la API de OpenAI para transcripción
        logger.info(f"Enviando {len(audio_data)} bytes para transcripción")

        client = openai.OpenAI(api_key=OPENAI_API_KEY)
        response = client.audio.transcriptions.create(
            model="whisper-1",
            file=audio_file,
            language=language,
            response_format="text",
        )

        text = response  # El resultado de la transcripción está en response.text

        # Devuelve el resultado de la transcripción
        logger.info(f"Transcripción completada: {text[:30]}...")
        return {"success": True, "text": text}

    # Devuelve un error si la transcripción falla
    except Exception as e:
        logger.error(f"Error durante la transcripción: {str(e)}")
        return {"success": False, "error": str(e)}
