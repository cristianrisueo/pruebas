# websocket_config.py contiene la clase ConnectionManager que gestiona las conexiones WebSocket

import logging
import uuid
from typing import Dict, List
from fastapi import WebSocket

# Configuración del logger
logger = logging.getLogger(__name__)


class ConnectionManager:
    """
    Clase que gestiona las conexiones WebSocket.
    __init__: Inicializa la lista de conexiones activas y los IDs de conversación
    connect: Acepta una nueva conexión WebSocket y la añade a la lista de conexiones activas
    disconnect: Elimina una conexión WebSocket de la lista de conexiones activas
    send_text: Envía un mensaje de texto a una conexión WebSocket activa específica
    send_json: Envía un mensaje JSON a una conexión WebSocket activa específica
    get_conversation_id: Obtiene el ID de conversación para una conexión WebSocket
    reset_conversation: Reinicia la conversación para una conexión WebSocket
    """

    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.conversation_ids: Dict[WebSocket, str] = {}

    async def connect(self, websocket: WebSocket):
        await websocket.accept()

        # Añade la conexión a la lista de conexiones activas y genera un ID de conversación
        self.active_connections.append(websocket)
        self.conversation_ids[websocket] = str(uuid.uuid4())

        logger.info(
            f"Nueva conexión establecida. ID de conversación: {self.conversation_ids[websocket]}"
        )

    def disconnect(self, websocket: WebSocket):

        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

        if websocket in self.conversation_ids:
            logger.info(
                f"Conexión cerrada. ID de conversación: {self.conversation_ids[websocket]}"
            )

            del self.conversation_ids[websocket]

    async def send_text(self, message: str, websocket: WebSocket):
        await websocket.send_text(message)

    async def send_json(self, data: dict, websocket: WebSocket):
        await websocket.send_json(data)

    def get_conversation_id(self, websocket: WebSocket) -> str:
        return self.conversation_ids.get(websocket, str(uuid.uuid4()))

    async def reset_conversation(self, websocket: WebSocket, chatgpt_service) -> None:
        conversation_id = self.get_conversation_id(websocket)
        result = chatgpt_service.clear_conversation(conversation_id)

        await self.send_json(result, websocket)


# Instancia el gestor de conexiones
manager = ConnectionManager()
